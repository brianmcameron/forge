#!/usr/bin/env python3
"""Builds docs/trends.json: the ten workout formats most often mentioned in the last week of
public news coverage (Google News RSS), each with a full exercise list the app can load.
Honest by design: a workout's rank comes from real headline counts; nothing is invented.
usage: build_trends.py OUT_JSON [--fixture headlines.json]
"""
import argparse, datetime as dt, email.utils, hashlib, json, os, re, sys, urllib.parse, urllib.request
import xml.etree.ElementTree as ET

QUERIES = ['viral workout men', 'TikTok workout trend men', 'Instagram workout trend men', 'YouTube workout routine men viral',
           'best workout for men this week', 'popular gym routine men', 'workout challenge men', 'fitness trend men 2026']

def fetch(q):
    url = 'https://news.google.com/rss/search?q=' + urllib.parse.quote(q + ' when:7d') + '&hl=en-US&gl=US&ceid=US:en'
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    root = ET.fromstring(urllib.request.urlopen(req, timeout=30).read())
    out = []
    for it in root.iter('item'):
        d = None
        try: d = email.utils.parsedate_to_datetime(it.findtext('pubDate') or '')
        except Exception: pass
        out.append({'t': (it.findtext('title') or '').strip(), 'u': (it.findtext('link') or '').strip(), 'd': d.isoformat() if d else None})
    return out

def rank(workouts, heads, now):
    seen, uniq = set(), []
    for h in heads:
        k = re.sub(r'\W+', ' ', h['t'].lower())[:80]
        if k and k not in seen: seen.add(k); uniq.append(h)
    scored = []
    day = now.strftime('%Y-%m-%d')
    for w in workouts:
        pats = [re.compile(r'(?<![a-z0-9])' + re.escape(a.lower()) + r'(?![a-z0-9])') for a in w['aliases']]
        hit = []
        for h in uniq:
            if any(p.search(h['t'].lower()) for p in pats):
                age = 7
                if h['d']:
                    try: age = (now - dt.datetime.fromisoformat(h['d'])).total_seconds() / 86400
                    except Exception: pass
                hit.append((1.5 if age <= 2 else 1.0, h))
        tie = int(hashlib.md5((day + w['n']).encode()).hexdigest()[:6], 16)
        scored.append((sum(x[0] for x in hit), tie, w, [x[1] for x in hit]))
    scored.sort(key=lambda x: (-x[0], x[1]))
    items = []
    for score, _, w, hs in scored[:10]:
        it = {k: w[k] for k in ('n', 'focus', 'diff', 'min', 'equip', 'desc', 'b')}
        if hs:
            it['mentions'] = len(hs)
            it['why'] = f"Appeared in {len(hs)} news {'story' if len(hs) == 1 else 'stories'} this past week."
            it['src'] = {'t': hs[0]['t'][:140], 'u': hs[0]['u']}
        else:
            it['mentions'] = 0; it['why'] = w.get('why', 'A popular, well-tested format.')
        items.append(it)
    return items, len(uniq)

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--fixture'); a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__)); workouts = json.load(open(os.path.join(here, 'workouts.json'), encoding='utf-8'))
    heads = []
    if a.fixture: heads = json.load(open(a.fixture))
    else:
        for q in QUERIES:
            try: heads += fetch(q)
            except Exception as e: print('query failed:', q, e, file=sys.stderr)
    now = dt.datetime.now(dt.timezone.utc)
    items, n = rank(workouts, heads, now)
    if n < 5 and not a.fixture and os.path.exists(a.out):
        print('too little coverage found; keeping the previous file'); sys.exit(0)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump({'generated': now.isoformat(), 'headlines_seen': n, 'items': items}, open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('wrote', a.out, len(items), 'items from', n, 'headlines')
