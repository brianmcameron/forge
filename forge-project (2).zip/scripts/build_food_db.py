#!/usr/bin/env python3
"""Builds assets/foods.db (SQLite + FTS5) from the USDA FoodData Central CSV download.

usage: build_food_db.py OUT_DB [--mode full|lite] [--zip PATH] [--url URL]
  full = every food type incl. ~1.9M branded products   lite = Foundation + SR Legacy + FNDDS only (~20k foods)
Nutrition is stored per 100 g: kcal, protein, carbs, fat.
"""
import argparse, csv, io, os, re, sqlite3, sys, time, urllib.request, zipfile

csv.field_size_limit(1 << 30)
KCAL = {1008: 0, 2047: 1, 2048: 2}         # Energy (kcal), Atwater general / specific factors
PROT = {1003: 0}
FAT = {1004: 0, 1085: 1}                    # Total lipid, Total fat (NLEA)
CARB = {1005: 0, 1050: 1}                   # Carbohydrate by difference / by summation
WANT = set(KCAL) | set(PROT) | set(FAT) | set(CARB)
TYPES_LITE = {'foundation_food', 'sr_legacy_food', 'survey_fndds_food'}
TYPES_FULL = TYPES_LITE | {'branded_food'}
GRAMS = {'g', 'grm', 'gm', 'gram', 'grams', 'ml', 'mlt'}

def with_retries(fn, tries=4, base_delay=15, what='request'):
    """USDA's site occasionally 502/503/504s under load — retry a few times before giving up."""
    for i in range(tries):
        try:
            return fn()
        except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as e:
            if i == tries - 1: raise
            wait = base_delay * (i + 1)
            print(f'{what} failed ({e}), retrying in {wait}s ({i + 1}/{tries - 1})...', flush=True)
            time.sleep(wait)

def abs_url(u):
    return u if u.startswith('http') else 'https://fdc.nal.usda.gov' + ('' if u.startswith('/') else '/') + u

def find_urls(mode):
    """Lite mode prefers USDA's smaller, separate Foundation/SR Legacy/Survey(FNDDS) zips —
    each just a few MB to a couple hundred MB, instead of the ~500 MB combined file, which is
    slower and more likely to hit a server timeout. Falls back to the combined file if USDA's
    page layout doesn't match (their site has changed formats before)."""
    env = os.environ.get('FDC_URL', '').strip()
    if env: return [u.strip() for u in env.split(',') if u.strip()]
    def fetch():
        req = urllib.request.Request('https://fdc.nal.usda.gov/download-datasets', headers={'User-Agent': 'Mozilla/5.0'})
        return urllib.request.urlopen(req, timeout=60).read().decode('utf-8', 'replace')
    html = with_retries(fetch, what='fetching the USDA download page')
    all_links = sorted(set(abs_url(u) for u in re.findall(
        r'(?:href|url)=["\']?([^"\' >]*FoodData_Central_[A-Za-z_]*csv[0-9A-Za-z_-]*\.zip)', html)))
    if mode == 'lite':
        picked = []
        for want in ('foundation_food', 'sr_legacy_food', 'survey_food'):
            m = [u for u in all_links if want in u.lower()]
            if m: picked.append(sorted(m)[-1])
        if picked:
            print('lite mode: using', len(picked), 'separate USDA datasets instead of the full combined file:', flush=True)
            for u in picked: print(' -', u, flush=True)
            return picked
        print('lite mode: could not find the separate Foundation/SR Legacy/Survey zips on USDA\u2019s page; falling back to the full combined file (larger, slower).', flush=True)
    combined = [u for u in all_links if re.search(r'FoodData_Central_csv_[0-9-]+\.zip$', u, re.I)]
    if not combined: raise SystemExit('Could not find a FoodData Central CSV link. Re-run and paste one into the "fdc_url" box (comma-separate multiple links).')
    return [sorted(combined)[-1]]

def download(url, dest):
    def do():
        print('downloading', url, flush=True)
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=120) as r, open(dest, 'wb') as f:
            n = 0
            while True:
                b = r.read(1 << 20)
                if not b: break
                f.write(b); n += len(b)
                if n % (50 << 20) < (1 << 20): print(f'  {n >> 20} MB', flush=True)
    with_retries(do, what='downloading ' + url)

def member(z, base):
    for n in z.namelist():
        if n.split('/')[-1].lower() == base: return n
    return None

def rows(z, base):
    n = member(z, base)
    if not n: return iter(())
    return csv.DictReader(io.TextIOWrapper(z.open(n), encoding='utf-8-sig', newline=''))

def nice(s):
    s = (s or '').strip()
    if s and s == s.upper(): s = re.sub(r'(^|[\s,(/-])([a-z])', lambda m: m.group(1) + m.group(2).upper(), s.lower())
    return re.sub(r'\s+', ' ', s)[:110]

def build(zips, out, mode):
    """zips: one or more open zipfile.ZipFile objects; their food.csv / food_nutrient.csv /
    branded_food.csv rows are merged as if from a single archive."""
    def all_rows(base):
        for z in zips: yield from rows(z, base)
    types = TYPES_FULL if mode == 'full' else TYPES_LITE
    foods = {}
    for r in all_rows('food.csv'):
        t = r.get('data_type', '')
        if t in types and r.get('description'):
            foods[int(r['fdc_id'])] = [t, nice(r['description'])]
    print('foods in scope:', len(foods), flush=True)
    nut = {}
    for i, r in enumerate(all_rows('food_nutrient.csv')):
        try: fid = int(r['fdc_id']); nid = int(r['nutrient_id'])
        except (ValueError, KeyError): continue
        if nid not in WANT or fid not in foods: continue
        try: a = float(r['amount'])
        except ValueError: continue
        d = nut.setdefault(fid, {})
        if nid in KCAL: k = ('k', KCAL[nid])
        elif nid in PROT: k = ('p', 0)
        elif nid in FAT: k = ('f', FAT[nid])
        else: k = ('c', CARB[nid])
        cur = d.get(k[0])
        if cur is None or k[1] < cur[0]: d[k[0]] = (k[1], a)
        if i % 5_000_000 == 0 and i: print('  nutrient rows', i, flush=True)
    brand = {}
    if mode == 'full':
        for r in all_rows('branded_food.csv'):
            try: fid = int(r['fdc_id'])
            except (ValueError, KeyError): continue
            if fid not in foods: continue
            su = (r.get('serving_size_unit') or '').strip().lower()
            try: sv = float(r.get('serving_size') or 0)
            except ValueError: sv = 0
            brand[fid] = (nice(r.get('brand_name') or r.get('brand_owner') or '')[:40], round(sv) if su in GRAMS and 0 < sv < 2000 else None)
    if os.path.exists(out): os.remove(out)
    db = sqlite3.connect(out)
    db.executescript('''PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA page_size=4096;
      CREATE TABLE foods(id INTEGER PRIMARY KEY, name TEXT NOT NULL, brand TEXT, kcal REAL, p REAL, c REAL, f REAL, sg REAL, pri INTEGER);
      CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT);''')
    kept = dropped = 0; batch = []; seen = set()
    for fid, (t, name) in foods.items():
        d = nut.get(fid)
        if not d: dropped += 1; continue
        p = d['p'][1] if 'p' in d else None; c = d['c'][1] if 'c' in d else None; f = d['f'][1] if 'f' in d else None
        k = d['k'][1] if 'k' in d else None
        if p is None or c is None or f is None: dropped += 1; continue
        if k is None or k <= 0 and (p + c + f) > 1: k = p * 4 + c * 4 + f * 9
        if not (0 <= k <= 950 and min(p, c, f) >= 0 and p <= 100.5 and c <= 100.5 and f <= 100.5 and p + c + f <= 108):
            dropped += 1; continue
        b, sg = brand.get(fid, ('', None))
        key = (name.lower(), b.lower(), round(k), round(p, 1), round(c, 1), round(f, 1))
        if key in seen: dropped += 1; continue
        seen.add(key)
        batch.append((fid, name, b or None, round(k, 1), round(p, 1), round(c, 1), round(f, 1), sg, 1 if t == 'branded_food' else 0)); kept += 1
        if len(batch) >= 50000:
            db.executemany('INSERT INTO foods VALUES(?,?,?,?,?,?,?,?,?)', batch); batch = []
    if batch: db.executemany('INSERT INTO foods VALUES(?,?,?,?,?,?,?,?,?)', batch)
    db.commit(); print(f'kept {kept}, dropped {dropped}; building search index...', flush=True)
    db.executescript('''CREATE VIRTUAL TABLE foods_fts USING fts5(name, brand, content='foods', content_rowid='id',
        tokenize='unicode61 remove_diacritics 2', prefix='2 3 4');
      INSERT INTO foods_fts(foods_fts) VALUES('rebuild');
      INSERT INTO foods_fts(foods_fts) VALUES('optimize');''')
    db.execute("INSERT INTO meta VALUES('rows',?)", (str(kept),)); db.execute("INSERT INTO meta VALUES('mode',?)", (mode,))
    db.commit(); db.execute('VACUUM'); db.close()
    print('done:', out, round(os.path.getsize(out) / 1e6, 1), 'MB', kept, 'foods')

def build_empty(out, reason):
    """Used when USDA's servers can't be reached at all after every retry. Produces a
    schema-valid, empty database so the app still builds and installs — Forge's food search
    already falls back to live USDA/Open Food Facts lookups whenever the offline list comes up
    short, so search keeps working; you only lose the fully-offline database until a later
    rebuild succeeds."""
    if os.path.exists(out): os.remove(out)
    db = sqlite3.connect(out)
    db.executescript('''PRAGMA journal_mode=OFF;
      CREATE TABLE foods(id INTEGER PRIMARY KEY, name TEXT NOT NULL, brand TEXT, kcal REAL, p REAL, c REAL, f REAL, sg REAL, pri INTEGER);
      CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT);
      CREATE VIRTUAL TABLE foods_fts USING fts5(name, brand, content='foods', content_rowid='id',
        tokenize='unicode61 remove_diacritics 2', prefix='2 3 4');''')
    db.execute("INSERT INTO meta VALUES('rows','0')"); db.execute("INSERT INTO meta VALUES('mode','empty')")
    db.execute("INSERT INTO meta VALUES('note',?)", (reason,))
    db.commit(); db.close()
    print(f'::warning::Could not build the offline food database ({reason}). Shipping an empty one — '
          f'online food search still works. Re-run this workflow later to fill it in.', flush=True)

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--mode', default='full', choices=['full', 'lite']); ap.add_argument('--zip'); ap.add_argument('--url')
    a = ap.parse_args()
    try:
        if a.zip:
            paths = [p.strip() for p in a.zip.split(',') if p.strip()]; cleanup = []
        else:
            urls = [u.strip() for u in a.url.split(',') if u.strip()] if a.url else find_urls(a.mode)
            paths = [f'fdc_{i}.zip' for i in range(len(urls))]
            for u, p in zip(urls, paths): download(u, p)
            cleanup = paths
        zips = [zipfile.ZipFile(p) for p in paths]
        try:
            build(zips, a.out, a.mode)
        finally:
            for z in zips: z.close()
            for p in cleanup:
                if os.path.exists(p): os.remove(p)
    except SystemExit:
        raise  # a real usage error (e.g. bad --mode) should still stop the build
    except Exception as e:
        build_empty(a.out, str(e))
