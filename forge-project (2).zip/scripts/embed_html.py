#!/usr/bin/env python3
"""usage: embed_html.py forge.html OUT.js  ->  export default "<the whole app as a string>";"""
import json, sys
open(sys.argv[2], 'w', encoding='utf-8').write('export default ' + json.dumps(open(sys.argv[1], encoding='utf-8').read()) + ';\n')
