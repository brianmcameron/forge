import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

const ID = 'forge-workout';
let channelReady = null;

async function ensureChannel() {
  if (Platform.OS !== 'android') return;
  if (channelReady) return channelReady;
  channelReady = Notifications.setNotificationChannelAsync('workout', {
    name: 'Active workout',
    importance: Notifications.AndroidImportance.LOW, // quiet updates, no repeated sound/buzz
    sound: null,
  });
  return channelReady;
}

// Re-posting a notification with the same identifier replaces its content in place on
// Android rather than stacking a new one — this is how we get a live-updating card
// without a full custom foreground service, which Expo's managed workflow can't build.
// Caveat: Android may pause background JS after the app has been out of view for a
// while, so "live" here means "updates whenever Forge gets to run", not a guaranteed
// per-second tick while fully backgrounded.
export async function updateWorkoutNotification({ title, body }) {
  try {
    await ensureChannel();
    await Notifications.scheduleNotificationAsync({
      identifier: ID,
      content: {
        title,
        body,
        sound: null,
        sticky: true,
        autoDismiss: false,
        ...(Platform.OS === 'android' ? { channelId: 'workout' } : {}),
      },
      trigger: null, // show immediately; re-calling this replaces the same notification
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, message: e?.message || 'Could not update the notification' };
  }
}

export async function clearWorkoutNotification() {
  try { await Notifications.dismissNotificationAsync(ID); } catch (e) { /* already gone */ }
  return { ok: true };
}
