import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { GOOGLE_WEB_CLIENT_ID } from './config';

// Filled in by you after creating the OAuth clients in Google Cloud Console — see setup notes.
// This must be the "Web application" client ID from the SAME project as the Android client
// (the Android client itself is never referenced here; it's matched automatically by
// your app's package name + signing certificate SHA-1). Edit the value in src/config.js.

let configured = false;
function ensureConfigured() {
  if (configured) return;
  GoogleSignin.configure({
    webClientId: GOOGLE_WEB_CLIENT_ID,
    scopes: ['profile', 'email', 'https://www.googleapis.com/auth/drive.file'],
    offlineAccess: false,
  });
  configured = true;
}

export async function googleSignIn() {
  ensureConfigured();
  try {
    await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
    const res = await GoogleSignin.signIn();
    const user = res.data ?? res; // library shape has varied across versions; handle both
    return {
      ok: true,
      name: user?.user?.name || '',
      email: user?.user?.email || '',
      photo: user?.user?.photo || null,
    };
  } catch (e) {
    return { ok: false, message: e?.message || 'Sign-in failed' };
  }
}

export async function googleSignOut() {
  try { await GoogleSignin.signOut(); } catch (e) { /* ignore */ }
  return { ok: true };
}

// Returns a fresh access token, letting Play Services silently refresh it under the hood.
export async function getAccessToken() {
  ensureConfigured();
  const isSignedIn = await GoogleSignin.getCurrentUser();
  if (!isSignedIn) throw new Error('Not signed in');
  const tokens = await GoogleSignin.getTokens();
  return tokens.accessToken;
}
