import { getAccessToken } from './googleAuth';

const BACKUP_NAME = 'forge-backup.json';
const API = 'https://www.googleapis.com/drive/v3/files';
const UPLOAD_API = 'https://www.googleapis.com/upload/drive/v3/files';

async function authedFetch(url, opts = {}, retried = false) {
  const token = await getAccessToken();
  const res = await fetch(url, { ...opts, headers: { ...(opts.headers || {}), Authorization: `Bearer ${token}` } });
  if (res.status === 401 && !retried) {
    // token might have just expired; getAccessToken() already asks Play Services for a
    // current one each call, so a second attempt is usually enough.
    return authedFetch(url, opts, true);
  }
  return res;
}

async function findBackupFileId() {
  const q = encodeURIComponent(`name='${BACKUP_NAME}' and trashed=false`);
  const res = await authedFetch(`${API}?q=${q}&spaces=drive&fields=files(id,modifiedTime)&pageSize=1`);
  if (!res.ok) throw new Error('Drive list failed: ' + res.status);
  const data = await res.json();
  return (data.files && data.files[0]) ? data.files[0].id : null;
}

export async function driveBackupNow(json) {
  try {
    const id = await findBackupFileId();
    const boundary = 'forge-boundary-' + Date.now();
    const metadata = id ? {} : { name: BACKUP_NAME, mimeType: 'application/json' };
    const body =
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n` +
      `--${boundary}\r\nContent-Type: application/json\r\n\r\n${json}\r\n--${boundary}--`;
    const url = id
      ? `${UPLOAD_API}/${id}?uploadType=multipart`
      : `${UPLOAD_API}?uploadType=multipart`;
    const res = await authedFetch(url, {
      method: id ? 'PATCH' : 'POST',
      headers: { 'Content-Type': `multipart/related; boundary=${boundary}` },
      body,
    });
    if (!res.ok) return { ok: false, message: 'Drive upload failed: ' + res.status };
    return { ok: true };
  } catch (e) {
    return { ok: false, message: e?.message || 'Backup failed' };
  }
}

export async function driveRestore() {
  try {
    const id = await findBackupFileId();
    if (!id) return { ok: false, message: 'No backup found in Drive yet' };
    const res = await authedFetch(`${API}/${id}?alt=media`);
    if (!res.ok) return { ok: false, message: 'Drive download failed: ' + res.status };
    const json = await res.text();
    return { ok: true, json };
  } catch (e) {
    return { ok: false, message: e?.message || 'Restore failed' };
  }
}
