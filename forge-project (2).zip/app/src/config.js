// Overwritten by the CI job with your repository's address. Only used as a placeholder while developing.
export const TRENDS_URL = 'https://raw.githubusercontent.com/OWNER/REPO/main/docs/trends.json';
// Overwritten by the CI job from the workflow's "Google Web Client ID" input, if provided.
// Leave as-is if you haven't set up Google Sign-In yet — the app just hides that feature.
export const GOOGLE_WEB_CLIENT_ID = '252029458943-5827eu9ifhliroht21v38a2lqskjdhmf.apps.googleusercontent.com';
