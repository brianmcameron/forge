import { initialize, requestPermission, getGrantedPermissions, readRecords, getSdkStatus, SdkAvailabilityStatus } from 'react-native-health-connect';

const TYPES = ['Steps', 'ActiveCaloriesBurned', 'TotalCaloriesBurned', 'Distance', 'FloorsClimbed', 'HeartRate', 'RestingHeartRate', 'HeartRateVariabilityRmssd', 'OxygenSaturation', 'RespiratoryRate', 'BodyTemperature', 'BloodPressure', 'Vo2Max', 'Weight', 'BodyFat', 'SleepSession', 'ExerciseSession'];
const PERMS = TYPES.map((recordType) => ({ accessType: 'read', recordType }));

export async function healthStatus() {
  try {
    const s = await getSdkStatus();
    if (s === SdkAvailabilityStatus.SDK_UNAVAILABLE) return { status: 'unavailable', message: 'Health Connect isn’t available on this phone.' };
    if (s === SdkAvailabilityStatus.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED) return { status: 'update', message: 'Update Health Connect in the Play Store, then try again.' };
    if (!(await initialize())) return { status: 'unavailable', message: 'Couldn’t start Health Connect.' };
    const g = await getGrantedPermissions();
    return { status: 'ready', granted: g.some((p) => p.recordType === 'Steps') };
  } catch (e) { return { status: 'unavailable', message: 'Health Connect isn’t available.' }; }
}

export async function healthConnect() {
  if (!(await initialize())) return { granted: false };
  const res = await requestPermission(PERMS);
  return { granted: res.some((p) => p.recordType === 'Steps') };
}

const iso = (d) => d.toISOString();
// Health Connect timestamps need to be bucketed by the device's LOCAL calendar day, not UTC —
// toISOString() always returns UTC, so an evening session can silently roll into the next
// day's date bucket depending on timezone. This matches web's dkey() logic exactly.
const localDay = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const latest = (recs, key) => {
  const r = [...(recs || [])].sort((a, b) => new Date(b.time || b.startTime || 0) - new Date(a.time || a.startTime || 0))[0];
  return r ? r[key] : null;
};

// Health Connect's plain aggregate sums every app that wrote a record for the period — if
// both your phone's own tracker and a watch app (Zepp, etc.) are both writing the same
// underlying activity, that silently double- (or triple-) counts it. Instead we read the
// raw per-source records, sum within each source, and take the largest single source's
// total, which matches what any one tracker on its own would report — in practice, the
// dedicated fitness tracker (e.g. Zepp) almost always dominates the phone's own passive count.
async function sumByBestSource(recordType, range, valueField) {
  try {
    const res = await readRecords(recordType, { timeRangeFilter: range });
    const bySource = {};
    for (const r of (res && res.records) || []) {
      const origin = (r.metadata && r.metadata.dataOrigin && r.metadata.dataOrigin.packageName) || 'unknown';
      const v = typeof valueField === 'function' ? valueField(r) : (r[valueField] || 0);
      bySource[origin] = (bySource[origin] || 0) + (v || 0);
    }
    const totals = Object.values(bySource);
    return totals.length ? Math.max(...totals) : 0;
  } catch (e) { return 0; }
}
async function stepsForRange(range) { return sumByBestSource('Steps', range, 'count'); }
async function activeCaloriesForRange(range) { return sumByBestSource('ActiveCaloriesBurned', range, (r) => r.energy && r.energy.inKilocalories); }
async function totalCaloriesForRange(range) { return sumByBestSource('TotalCaloriesBurned', range, (r) => r.energy && r.energy.inKilocalories); }
async function distanceForRange(range) { return sumByBestSource('Distance', range, (r) => r.distance && r.distance.inMeters ? r.distance.inMeters / 1609.34 : 0); }
async function floorsForRange(range) { return sumByBestSource('FloorsClimbed', range, 'floors'); }

export async function healthToday() {
  const now = new Date();
  const start = new Date(now); start.setHours(0, 0, 0, 0);
  const day = { operator: 'between', startTime: iso(start), endTime: iso(now) };
  const week = { operator: 'between', startTime: iso(new Date(now.getTime() - 7 * 864e5)), endTime: iso(now) };
  const month = { operator: 'between', startTime: iso(new Date(now.getTime() - 30 * 864e5)), endTime: iso(now) };
  const nap = { operator: 'between', startTime: iso(new Date(now.getTime() - 36 * 36e5)), endTime: iso(now) };
  const safe = async (fn) => { try { return await fn(); } catch (_) { return null; } };
  const [steps, activeKcal, totalKcal, distance, floors, hr, rhr, hrv, spo2, resp, temp, bp, vo2, weight, bodyFat, sleep] = await Promise.all([
    safe(() => stepsForRange(day)),
    safe(() => activeCaloriesForRange(day)),
    safe(() => totalCaloriesForRange(day)),
    safe(() => distanceForRange(day)),
    safe(() => floorsForRange(day)),
    safe(() => readRecords('HeartRate', { timeRangeFilter: day })),
    safe(() => readRecords('RestingHeartRate', { timeRangeFilter: week })),
    safe(() => readRecords('HeartRateVariabilityRmssd', { timeRangeFilter: week })),
    safe(() => readRecords('OxygenSaturation', { timeRangeFilter: week })),
    safe(() => readRecords('RespiratoryRate', { timeRangeFilter: week })),
    safe(() => readRecords('BodyTemperature', { timeRangeFilter: week })),
    safe(() => readRecords('BloodPressure', { timeRangeFilter: week })),
    safe(() => readRecords('Vo2Max', { timeRangeFilter: month })),
    safe(() => readRecords('Weight', { timeRangeFilter: month })),
    safe(() => readRecords('BodyFat', { timeRangeFilter: month })),
    safe(() => readRecords('SleepSession', { timeRangeFilter: nap })),
  ]);
  let sleepMs = 0;
  ((sleep && sleep.records) || []).forEach((r) => { sleepMs += Math.max(0, new Date(r.endTime) - new Date(r.startTime)); });
  const w = latest(weight && weight.records, 'weight');
  const bf = latest(bodyFat && bodyFat.records, 'percentage');
  const bpLast = (bp && bp.records && bp.records[bp.records.length - 1]) || null;
  // live heart rate records store a series of samples per record; take the most recent sample of the most recent record
  let hrLast = 0;
  if (hr && hr.records && hr.records.length) {
    const last = hr.records[hr.records.length - 1];
    const s = last.samples && last.samples.length ? last.samples[last.samples.length - 1] : null;
    hrLast = (s && s.beatsPerMinute) || 0;
  }
  return {
    steps: steps || 0,
    activeKcal: activeKcal || 0,
    totalKcal: totalKcal || 0,
    distanceMi: distance || 0,
    floors: floors || 0,
    hr: hrLast,
    rhr: latest(rhr && rhr.records, 'beatsPerMinute') || 0,
    hrv: latest(hrv && hrv.records, 'heartRateVariabilityMillis') || 0,
    spo2: latest(spo2 && spo2.records, 'percentage') || 0,
    respRate: latest(resp && resp.records, 'rate') || 0,
    bodyTempF: (() => { const t = latest(temp && temp.records, 'temperature'); return t && t.inFahrenheit ? t.inFahrenheit : 0; })(),
    bpSystolic: (bpLast && bpLast.systolic && bpLast.systolic.inMillimetersOfMercury) || 0,
    bpDiastolic: (bpLast && bpLast.diastolic && bpLast.diastolic.inMillimetersOfMercury) || 0,
    vo2Max: latest(vo2 && vo2.records, 'vo2MillilitersPerMinuteKilogram') || 0,
    weightLb: (w && (w.inPounds || (w.inKilograms ? w.inKilograms * 2.20462 : 0))) || 0,
    bodyFatPct: (bf && bf.percentage) || 0,
    sleepH: sleepMs / 36e5,
  };
}

// Exercise type numbers per the Health Connect schema (a subset covering what Strava, Garmin
// Connect, and similar apps commonly write). Anything not in this map falls back to 'Workout'.
const EXERCISE_TYPE_NAMES = {
  56: 'Running', 8: 'Biking', 79: 'Walking', 1: 'Badminton', 2: 'Baseball', 4: 'Basketball',
  6: 'Boxing', 68: 'Swimming pool', 71: 'Swimming open water', 61: 'Rowing', 76: 'Strength training',
  13: 'Calisthenics', 27: 'Elliptical', 45: 'Hiking', 59: 'Rock climbing', 78: 'Volleyball',
  82: 'Yoga', 26: 'Dancing', 44: 'Guided breathing', 24: 'CrossFit', 84: 'Wheelchair',
};
function exerciseName(type) { return EXERCISE_TYPE_NAMES[type] || 'Workout'; }

// Pulls full exercise sessions (not just daily totals) for the last N days — this is how
// activities from Strava, Garmin Connect, etc. show up, since those apps write their own
// ExerciseSession + distance records into Health Connect when the user enables that sync.
// Pulls the same daily aggregates as healthToday(), but for each of the past N days —
// this is what lets weekly totals (steps, distance, calories) actually be complete
// instead of only reflecting whichever single day you last synced.
export async function healthHistory(days = 7) {
  const safe = async (fn) => { try { return await fn(); } catch (_) { return null; } };
  const out = [];
  for (let i = 1; i < days; i++) { // i=0 (today) is already covered by healthToday()
    const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0); dayStart.setDate(dayStart.getDate() - i);
    const dayEnd = new Date(dayStart); dayEnd.setDate(dayStart.getDate() + 1);
    const range = { operator: 'between', startTime: iso(dayStart), endTime: iso(dayEnd) };
    const [steps, activeKcal, totalKcal, distance, floors] = await Promise.all([
      safe(() => stepsForRange(range)),
      safe(() => activeCaloriesForRange(range)),
      safe(() => totalCaloriesForRange(range)),
      safe(() => distanceForRange(range)),
      safe(() => floorsForRange(range)),
    ]);
    out.push({
      date: localDay(dayStart),
      steps: steps || 0,
      activeKcal: activeKcal || 0,
      totalKcal: totalKcal || 0,
      distanceMi: distance || 0,
      floors: floors || 0,
    });
  }
  return out;
}

export async function healthExerciseSessions(days = 7) {
  try {
    const now = new Date();
    const range = { operator: 'between', startTime: iso(new Date(now.getTime() - days * 864e5)), endTime: iso(now) };
    const sessions = await readRecords('ExerciseSession', { timeRangeFilter: range });
    const out = [];
    for (const s of (sessions && sessions.records) || []) {
      const start = new Date(s.startTime), end = new Date(s.endTime);
      const minutes = Math.max(1, Math.round((end - start) / 60000));
      let distanceMi = 0;
      try { distanceMi = await distanceForRange({ operator: 'between', startTime: s.startTime, endTime: s.endTime }); } catch (_) { /* not every session has distance */ }
      out.push({
        id: s.metadata && s.metadata.id ? String(s.metadata.id) : `${s.startTime}-${s.exerciseType}`,
        date: localDay(start),
        name: s.title || exerciseName(s.exerciseType),
        minutes,
        distanceMi: Math.round(distanceMi * 100) / 100,
        source: (s.metadata && s.metadata.dataOrigin && s.metadata.dataOrigin.packageName) || 'Health Connect',
      });
    }
    return out;
  } catch (e) { return []; }
}
