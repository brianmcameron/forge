// Overwritten by the CI job with your repository's address. Only used as a placeholder while developing.
export const TRENDS_URL = 'https://raw.githubusercontent.com/OWNER/REPO/main/docs/trends.json';
// Same idea for the ingredient-tracking reference values (RDA/UL per nutrient) — a static file
// seeded once by the trends job, editable directly in the repo, fetched by the app about once a
// day so updated numbers don't require a new build.
export const NUTRIENT_REF_URL = 'https://raw.githubusercontent.com/OWNER/REPO/main/docs/nutrient-ref.json';
// Overwritten by the CI job from the workflow's "Google Web Client ID" input, if provided.
// Leave as-is if you haven't set up Google Sign-In yet — the app just hides that feature.
export const GOOGLE_WEB_CLIENT_ID = '252029458943-5827eu9ifhliroht21v38a2lqskjdhmf.apps.googleusercontent.com';
