// Overwritten by the CI job with your repository's address. Only used as a placeholder while developing.
export const TRENDS_URL = 'https://raw.githubusercontent.com/OWNER/REPO/main/docs/trends.json';
// Overwritten by the CI job from the workflow's "Google Web Client ID" input, if provided.
// Leave as-is if you haven't set up Google Sign-In yet — the app just hides that feature.
export const GOOGLE_WEB_CLIENT_ID = 'YOUR_WEB_CLIENT_ID.apps.googleusercontent.com';
