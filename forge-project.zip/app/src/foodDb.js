import * as SQLite from 'expo-sqlite';

// foods.db is built by the CI job (scripts/build_food_db.py) from the USDA FoodData Central download.
// Schema: foods(id,name,brand,kcal,p,c,f,sg,pri) + foods_fts (FTS5) + meta(k,v). Nutrition is per 100 g.
const ASSET = require('../assets/foods.db');

let db = null;
let status = 'importing'; // importing | ready | error
let error = null;
let starting = null;

export function initFoodDb() {
  if (starting) return starting;
  starting = (async () => {
    try {
      let d = await SQLite.openDatabaseAsync('foods.db');
      let ok = false;
      try {
        const r = await d.getFirstAsync("SELECT v FROM meta WHERE k='rows'");
        ok = !!(r && +r.v > 0);
      } catch (_) { ok = false; }
      if (!ok) {
        try { await d.closeAsync(); } catch (_) {}
        await SQLite.importDatabaseFromAssetAsync('foods.db', { assetId: ASSET, forceOverwrite: true });
        d = await SQLite.openDatabaseAsync('foods.db');
      }
      db = d; status = 'ready';
    } catch (e) { status = 'error'; error = String((e && e.message) || e); }
  })();
  return starting;
}

const toks = (q) => String(q).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter(Boolean).slice(0, 6);

async function run(expr, limit) {
  return db.getAllAsync(
    `SELECT f.name AS name, f.brand AS brand, f.kcal AS kcal, f.p AS p, f.c AS c, f.f AS f, f.sg AS serving
       FROM foods_fts JOIN foods f ON f.id = foods_fts.rowid
      WHERE foods_fts MATCH ?
      ORDER BY f.pri, bm25(foods_fts, 8.0, 1.0)
      LIMIT ?`, [expr, limit]);
}

export async function searchFoods(q, limit = 24) {
  if (status === 'importing') return { status: 'importing', items: [] };
  if (status === 'error') return { status: 'error', error, items: [] };
  const t = toks(q);
  if (!t.length || t.join('').length < 2) return { status: 'ready', items: [] };
  let rows = [];
  try { rows = await run(t.map((x) => `"${x}"*`).join(' '), limit); } catch (_) { rows = []; }
  if (rows.length < 3 && t.some((x) => x.length > 4)) {
    // typo rescue: match on the first four letters of each longer word
    try { const alt = await run(t.map((x) => `"${x.length > 4 ? x.slice(0, 4) : x}"*`).join(' '), limit); const seen = new Set(rows.map((r) => r.name + '|' + r.brand)); for (const r of alt) if (!seen.has(r.name + '|' + r.brand)) rows.push(r); } catch (_) {}
  }
  return {
    status: 'ready',
    items: rows.slice(0, limit).map((r) => ({ name: r.brand ? `${r.name} — ${r.brand}` : r.name, kcal: r.kcal, p: r.p, c: r.c, f: r.f, serving: r.serving })),
  };
}
