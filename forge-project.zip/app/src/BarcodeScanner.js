import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';

// A full-screen barcode scanner shown over the WebView while active. Scans common
// retail product barcode formats (what's on food packaging) and reports the raw
// value back once, then stays inactive until dismissed to avoid firing repeatedly
// on the same code while the camera is still pointed at it.
export default function BarcodeScanner({ onScan, onCancel }) {
  const [permission, requestPermission] = useCameraPermissions();
  const [locked, setLocked] = useState(false);

  const handleScanned = useCallback((result) => {
    if (locked) return;
    setLocked(true);
    onScan(result.data);
  }, [locked, onScan]);

  if (!permission) return <View style={styles.fill} />;

  if (!permission.granted) {
    return (
      <View style={[styles.fill, styles.center]}>
        <Text style={styles.msg}>Forge needs camera access to scan a barcode.</Text>
        <Pressable style={styles.btn} onPress={requestPermission}>
          <Text style={styles.btnText}>Allow camera</Text>
        </Pressable>
        <Pressable style={styles.cancelBtn} onPress={onCancel}>
          <Text style={styles.cancelText}>Cancel</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.fill}>
      <CameraView
        style={styles.fill}
        facing="back"
        barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e', 'code128'] }}
        onBarcodeScanned={handleScanned}
      />
      <View style={styles.overlay} pointerEvents="box-none">
        <View style={styles.frame} />
        <Text style={styles.hint}>Point the camera at a barcode</Text>
        <Pressable style={styles.cancelBtn} onPress={onCancel}>
          <Text style={styles.cancelText}>Cancel</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1, backgroundColor: '#000' },
  center: { alignItems: 'center', justifyContent: 'center', padding: 24 },
  overlay: { position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center' },
  frame: { width: 260, height: 160, borderWidth: 3, borderColor: '#EB1B76', borderRadius: 16, backgroundColor: 'transparent' },
  hint: { color: '#fff', marginTop: 20, fontSize: 14, fontWeight: '600' },
  msg: { color: '#fff', fontSize: 15, textAlign: 'center', marginBottom: 20 },
  btn: { backgroundColor: '#EB1B76', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 12, marginBottom: 14 },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  cancelBtn: { position: 'absolute', bottom: 50, paddingVertical: 10, paddingHorizontal: 20 },
  cancelText: { color: '#fff', fontWeight: '600', fontSize: 14, opacity: 0.85 },
});
