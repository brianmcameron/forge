import { initialize, requestPermission, getGrantedPermissions, readRecords, aggregateRecord, getSdkStatus, SdkAvailabilityStatus } from 'react-native-health-connect';

const TYPES = ['Steps', 'ActiveCaloriesBurned', 'Distance', 'RestingHeartRate', 'HeartRateVariabilityRmssd', 'OxygenSaturation', 'Weight', 'SleepSession', 'ExerciseSession'];
const PERMS = TYPES.map((recordType) => ({ accessType: 'read', recordType }));

export async function healthStatus() {
  try {
    const s = await getSdkStatus();
    if (s === SdkAvailabilityStatus.SDK_UNAVAILABLE) return { status: 'unavailable', message: 'Health Connect isn’t available on this phone.' };
    if (s === SdkAvailabilityStatus.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED) return { status: 'update', message: 'Update Health Connect in the Play Store, then try again.' };
    if (!(await initialize())) return { status: 'unavailable', message: 'Couldn’t start Health Connect.' };
    const g = await getGrantedPermissions();
    return { status: 'ready', granted: g.some((p) => p.recordType === 'Steps') };
  } catch (e) { return { status: 'unavailable', message: 'Health Connect isn’t available.' }; }
}

export async function healthConnect() {
  if (!(await initialize())) return { granted: false };
  const res = await requestPermission(PERMS);
  return { granted: res.some((p) => p.recordType === 'Steps') };
}

const iso = (d) => d.toISOString();
const latest = (recs, key) => {
  const r = [...(recs || [])].sort((a, b) => new Date(b.time || b.startTime || 0) - new Date(a.time || a.startTime || 0))[0];
  return r ? r[key] : null;
};

export async function healthToday() {
  const now = new Date();
  const start = new Date(now); start.setHours(0, 0, 0, 0);
  const day = { operator: 'between', startTime: iso(start), endTime: iso(now) };
  const week = { operator: 'between', startTime: iso(new Date(now.getTime() - 7 * 864e5)), endTime: iso(now) };
  const month = { operator: 'between', startTime: iso(new Date(now.getTime() - 30 * 864e5)), endTime: iso(now) };
  const nap = { operator: 'between', startTime: iso(new Date(now.getTime() - 36 * 36e5)), endTime: iso(now) };
  const safe = async (fn) => { try { return await fn(); } catch (_) { return null; } };
  const [steps, kcal, rhr, hrv, spo2, weight, sleep] = await Promise.all([
    safe(() => aggregateRecord({ recordType: 'Steps', timeRangeFilter: day })),
    safe(() => aggregateRecord({ recordType: 'ActiveCaloriesBurned', timeRangeFilter: day })),
    safe(() => readRecords('RestingHeartRate', { timeRangeFilter: week })),
    safe(() => readRecords('HeartRateVariabilityRmssd', { timeRangeFilter: week })),
    safe(() => readRecords('OxygenSaturation', { timeRangeFilter: week })),
    safe(() => readRecords('Weight', { timeRangeFilter: month })),
    safe(() => readRecords('SleepSession', { timeRangeFilter: nap })),
  ]);
  let sleepMs = 0;
  ((sleep && sleep.records) || []).forEach((r) => { sleepMs += Math.max(0, new Date(r.endTime) - new Date(r.startTime)); });
  const w = latest(weight && weight.records, 'weight');
  return {
    steps: (steps && steps.COUNT_TOTAL) || 0,
    activeKcal: (kcal && kcal.ACTIVE_CALORIES_TOTAL && kcal.ACTIVE_CALORIES_TOTAL.inKilocalories) || 0,
    rhr: latest(rhr && rhr.records, 'beatsPerMinute') || 0,
    hrv: latest(hrv && hrv.records, 'heartRateVariabilityMillis') || 0,
    spo2: latest(spo2 && spo2.records, 'percentage') || 0,
    weightLb: (w && (w.inPounds || (w.inKilograms ? w.inKilograms * 2.20462 : 0))) || 0,
    sleepH: sleepMs / 36e5,
  };
}
