import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { GOOGLE_WEB_CLIENT_ID } from './config';

// Filled in by you after creating the OAuth clients in Google Cloud Console — see setup notes.
// This must be the "Web application" client ID from the SAME project as the Android client
// (the Android client itself is never referenced here; it's matched automatically by
// your app's package name + signing certificate SHA-1). Edit the value in src/config.js.

// calendar.readonly (and drive.file) were added after Forge's first release. Anyone who signed in
// before those existed is on a narrower grant, and — this is the part the earlier fix got wrong —
// neither a plain signIn() NOR a revokeAccess()+signOut()+signIn() cycle is guaranteed to actually
// show the consent screen for them: Android's Play Services can resolve signIn() from a cached
// device credential and report success without ever re-prompting for scopes added later, and
// revokeAccess() can silently no-op (it's wrapped in an empty catch in googleSignOut() below, so a
// failure there is invisible). GoogleSignin.addScopes() is the library's documented way to force an
// explicit incremental-consent screen for whatever scopes aren't already granted, independent of
// however signIn() resolved — so it's called after every sign-in as a belt-and-suspenders check,
// and reconnectGoogleAccess() below exposes the same call on its own so a stuck grant can be fixed
// without a full sign-out/sign-in round trip.
const EXTRA_SCOPES = ['https://www.googleapis.com/auth/drive.file', 'https://www.googleapis.com/auth/calendar.readonly'];

let configured = false;
function ensureConfigured() {
  if (configured) return;
  GoogleSignin.configure({
    webClientId: GOOGLE_WEB_CLIENT_ID,
    scopes: ['profile', 'email', ...EXTRA_SCOPES],
    offlineAccess: false,
  });
  configured = true;
}

export async function googleSignIn() {
  ensureConfigured();
  try {
    await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
    const res = await GoogleSignin.signIn();
    const user = res.data ?? res; // library shape has varied across versions; handle both
    try {
      await GoogleSignin.addScopes({ scopes: EXTRA_SCOPES });
    } catch (scopeErr) {
      // User may have backed out of the extra-scopes screen — sign-in itself still succeeded,
      // so don't fail the whole sign-in over it; reconnectGoogleAccess() can retry this later.
    }
    return {
      ok: true,
      name: user?.user?.name || '',
      email: user?.user?.email || '',
      photo: user?.user?.photo || null,
    };
  } catch (e) {
    return { ok: false, message: e?.message || 'Sign-in failed' };
  }
}

// Re-requests the Drive/Calendar scopes on their own, without touching the sign-in session at all.
// This is the fix for a grant that's stuck missing Calendar access even after a full sign-out and
// back in — addScopes() forces its own consent screen rather than relying on signIn() to show one.
export async function reconnectGoogleAccess() {
  ensureConfigured();
  try {
    const current = await GoogleSignin.getCurrentUser();
    if (!current) return { ok: false, message: 'Sign in with Google first' };
    await GoogleSignin.addScopes({ scopes: EXTRA_SCOPES });
    return { ok: true };
  } catch (e) {
    return { ok: false, message: e?.message || 'Could not update Google access' };
  }
}

export async function googleSignOut() {
  // signOut() alone only clears the LOCAL session — it does not revoke the access Google already
  // granted this app, so a following signIn() can silently reuse that old grant and skip the
  // consent screen entirely, including for any scope (like calendar.readonly) added after the
  // user's original grant. That's exactly the bug reported: sign out → sign back in → still no
  // calendar access, because nothing was actually re-prompted. revokeAccess() first forces Google
  // to treat the next signIn() as a fresh authorization, so the consent screen — now listing
  // calendar access — actually appears again.
  try { await GoogleSignin.revokeAccess(); } catch (e) { /* ignore — e.g. already revoked/signed out */ }
  try { await GoogleSignin.signOut(); } catch (e) { /* ignore */ }
  return { ok: true };
}

// Returns a fresh access token, letting Play Services silently refresh it under the hood.
export async function getAccessToken() {
  ensureConfigured();
  const isSignedIn = await GoogleSignin.getCurrentUser();
  if (!isSignedIn) throw new Error('Not signed in');
  const tokens = await GoogleSignin.getTokens();
  return tokens.accessToken;
}
