import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { GOOGLE_WEB_CLIENT_ID } from './config';

// Filled in by you after creating the OAuth clients in Google Cloud Console — see setup notes.
// This must be the "Web application" client ID from the SAME project as the Android client
// (the Android client itself is never referenced here; it's matched automatically by
// your app's package name + signing certificate SHA-1). Edit the value in src/config.js.

let configured = false;
function ensureConfigured() {
  if (configured) return;
  GoogleSignin.configure({
    webClientId: GOOGLE_WEB_CLIENT_ID,
    // calendar.readonly was added for the Connect→Today calendar sync. Anyone who signed in
    // before that feature existed is still on the narrower Drive-only grant — getAccessToken()
    // below won't include Calendar access for them until they sign out and back in once, which
    // is the only way this library can add a scope to an existing grant.
    scopes: ['profile', 'email', 'https://www.googleapis.com/auth/drive.file', 'https://www.googleapis.com/auth/calendar.readonly'],
    offlineAccess: false,
  });
  configured = true;
}

export async function googleSignIn() {
  ensureConfigured();
  try {
    await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
    const res = await GoogleSignin.signIn();
    const user = res.data ?? res; // library shape has varied across versions; handle both
    return {
      ok: true,
      name: user?.user?.name || '',
      email: user?.user?.email || '',
      photo: user?.user?.photo || null,
    };
  } catch (e) {
    return { ok: false, message: e?.message || 'Sign-in failed' };
  }
}

export async function googleSignOut() {
  // signOut() alone only clears the LOCAL session — it does not revoke the access Google already
  // granted this app, so a following signIn() can silently reuse that old grant and skip the
  // consent screen entirely, including for any scope (like calendar.readonly) added after the
  // user's original grant. That's exactly the bug reported: sign out → sign back in → still no
  // calendar access, because nothing was actually re-prompted. revokeAccess() first forces Google
  // to treat the next signIn() as a fresh authorization, so the consent screen — now listing
  // calendar access — actually appears again.
  try { await GoogleSignin.revokeAccess(); } catch (e) { /* ignore — e.g. already revoked/signed out */ }
  try { await GoogleSignin.signOut(); } catch (e) { /* ignore */ }
  return { ok: true };
}

// Returns a fresh access token, letting Play Services silently refresh it under the hood.
export async function getAccessToken() {
  ensureConfigured();
  const isSignedIn = await GoogleSignin.getCurrentUser();
  if (!isSignedIn) throw new Error('Not signed in');
  const tokens = await GoogleSignin.getTokens();
  return tokens.accessToken;
}
