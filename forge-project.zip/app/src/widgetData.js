import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'forge_widget_snapshot';

// The widget runs in a separate headless JS context from the main app (it can be asked to
// redraw even while Forge itself isn't open), so it can't reach into the WebView's
// localStorage directly. Instead, the web layer pushes a small summary here whenever it
// changes, and the widget just reads this snapshot.
export async function saveWidgetSnapshot(data) {
  try { await AsyncStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { /* best effort */ }
}

export async function loadWidgetSnapshot() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}

// Day-navigation offset for the Large widget's rings/bars (0 = today, 1 = yesterday, ... up to
// snapshot.days.length-1). Global rather than per-widget-instance — simpler, and matches how the
// web app's own Home day-nav is a single shared state (state.homeFocusDate), not per-viewport.
// Reset to 0 whenever a fresh snapshot is pushed (see resetWidgetDayOffset, called from App.js's
// updateWidgetData handler) so opening the app and coming back to the widget always starts on today.
const OFFSET_KEY = 'forge_widget_day_offset';
export async function loadWidgetDayOffset() {
  try { return parseInt((await AsyncStorage.getItem(OFFSET_KEY)) || '0', 10) || 0; } catch (e) { return 0; }
}
export async function saveWidgetDayOffset(n) {
  try { await AsyncStorage.setItem(OFFSET_KEY, String(n)); } catch (e) { /* best effort */ }
}
export async function resetWidgetDayOffset() {
  try { await AsyncStorage.setItem(OFFSET_KEY, '0'); } catch (e) { /* best effort */ }
}
