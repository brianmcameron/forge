import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'forge_widget_snapshot';

// The widget runs in a separate headless JS context from the main app (it can be asked to
// redraw even while Forge itself isn't open), so it can't reach into the WebView's
// localStorage directly. Instead, the web layer pushes a small summary here whenever it
// changes, and the widget just reads this snapshot.
export async function saveWidgetSnapshot(data) {
  try { await AsyncStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { /* best effort */ }
}

export async function loadWidgetSnapshot() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}
