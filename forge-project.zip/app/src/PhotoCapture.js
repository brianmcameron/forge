import React, { useState, useCallback, useRef } from 'react';
import { View, Text, StyleSheet, Pressable, ActivityIndicator } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';

// A full-screen still-photo capture shown over the WebView, sibling to BarcodeScanner but for the
// "read this label" flows (nutrition-facts panel, supplement bottle/bag) — those need a normal photo
// (not a barcode decode), which then gets run through on-device text recognition in App.js. Reusing
// expo-camera (already a dependency for the barcode scanner) avoids adding a second camera library.
export default function PhotoCapture({ hint, onCapture, onCancel }) {
  const [permission, requestPermission] = useCameraPermissions();
  const [torch, setTorch] = useState(false);
  const [busy, setBusy] = useState(false);
  const camRef = useRef(null);

  const shoot = useCallback(async () => {
    if (busy || !camRef.current) return;
    setBusy(true);
    try {
      const photo = await camRef.current.takePictureAsync({ quality: 0.85, skipProcessing: true });
      onCapture(photo && photo.uri ? photo.uri : null);
    } catch (e) {
      onCapture(null);
    }
  }, [busy, onCapture]);

  if (!permission) return <View style={styles.fill} />;

  if (!permission.granted) {
    return (
      <View style={[styles.fill, styles.center]}>
        <Text style={styles.msg}>Forge needs camera access to scan a label.</Text>
        <Pressable style={styles.btn} onPress={requestPermission}>
          <Text style={styles.btnText}>Allow camera</Text>
        </Pressable>
        <Pressable style={styles.cancelBtn} onPress={onCancel}>
          <Text style={styles.cancelText}>Cancel</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.fill}>
      <CameraView ref={camRef} style={styles.fill} facing="back" enableTorch={torch} />
      <View style={styles.overlay} pointerEvents="box-none">
        <View style={styles.frame} />
        <Text style={styles.hint}>{hint || 'Line up the label, then tap to capture'}</Text>
        <Pressable style={styles.flashBtn} onPress={() => setTorch(t => !t)} pointerEvents="auto">
          <Text style={styles.flashText}>{torch ? '⚡ Flash on' : '⚡ Flash off'}</Text>
        </Pressable>
        {busy ? (
          <View style={styles.shutter}><ActivityIndicator color="#fff" /></View>
        ) : (
          <Pressable style={styles.shutter} onPress={shoot} pointerEvents="auto">
            <View style={styles.shutterInner} />
          </Pressable>
        )}
        <Pressable style={styles.cancelBtn} onPress={onCancel} pointerEvents="auto">
          <Text style={styles.cancelText}>Cancel</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1, backgroundColor: '#000' },
  center: { alignItems: 'center', justifyContent: 'center', padding: 24 },
  overlay: { position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center' },
  frame: { width: 280, height: 200, borderWidth: 3, borderColor: '#EB1B76', borderRadius: 16, backgroundColor: 'transparent' },
  hint: { color: '#fff', marginTop: 20, fontSize: 14, fontWeight: '600', textAlign: 'center', paddingHorizontal: 30 },
  msg: { color: '#fff', fontSize: 15, textAlign: 'center', marginBottom: 20 },
  btn: { backgroundColor: '#EB1B76', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 12, marginBottom: 14 },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  cancelBtn: { position: 'absolute', bottom: 50, paddingVertical: 10, paddingHorizontal: 20 },
  cancelText: { color: '#fff', fontWeight: '600', fontSize: 14, opacity: 0.85 },
  flashBtn: { position: 'absolute', top: 60, right: 20, backgroundColor: 'rgba(0,0,0,0.55)', paddingVertical: 10, paddingHorizontal: 16, borderRadius: 20 },
  flashText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  shutter: { position: 'absolute', bottom: 110, width: 74, height: 74, borderRadius: 37, backgroundColor: 'rgba(255,255,255,.25)', borderWidth: 3, borderColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  shutterInner: { width: 58, height: 58, borderRadius: 29, backgroundColor: '#fff' },
});
