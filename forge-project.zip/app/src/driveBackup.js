import { googleAccessToken } from './googleAuth';

const FILE_NAME = 'forge-backup.json';
const API = 'https://www.googleapis.com/drive/v3/files';
const UPLOAD_API = 'https://www.googleapis.com/upload/drive/v3/files';

async function findBackupFile(token) {
  const q = encodeURIComponent(`name='${FILE_NAME}' and trashed=false`);
  const r = await fetch(`${API}?spaces=appDataFolder&q=${q}&fields=files(id,modifiedTime)`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!r.ok) throw new Error('drive list failed: ' + r.status);
  const j = await r.json();
  return (j.files && j.files[0]) || null;
}

// Writes the backup JSON into the app's hidden Drive appDataFolder (never the user's
// visible Drive), creating the file on first backup and updating it after that.
export async function driveBackup(json) {
  const token = await googleAccessToken();
  const existing = await findBackupFile(token);
  const body = new FormData();
  if (!existing) {
    body.append('metadata', new Blob([JSON.stringify({ name: FILE_NAME, parents: ['appDataFolder'] })], { type: 'application/json' }));
    body.append('file', new Blob([json], { type: 'application/json' }));
    const r = await fetch(`${UPLOAD_API}?uploadType=multipart&fields=id`, { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body });
    if (!r.ok) throw new Error('drive create failed: ' + r.status);
    return { ok: true, created: true };
  }
  const r = await fetch(`${UPLOAD_API}/${existing.id}?uploadType=media`, {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: json,
  });
  if (!r.ok) throw new Error('drive update failed: ' + r.status);
  return { ok: true, created: false, modifiedTime: existing.modifiedTime };
}

export async function driveRestore() {
  const token = await googleAccessToken();
  const existing = await findBackupFile(token);
  if (!existing) return { ok: false, reason: 'no_backup' };
  const r = await fetch(`${API}/${existing.id}?alt=media`, { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) throw new Error('drive download failed: ' + r.status);
  const text = await r.text();
  return { ok: true, json: text, modifiedTime: existing.modifiedTime };
}
