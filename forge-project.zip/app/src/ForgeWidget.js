import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';

// Rendered to native Android widgets (RemoteViews) by react-native-android-widget — this is NOT
// a normal React Native screen, only the subset of components that library supports. Three sizes
// share one snapshot shape (see widgetData.js / App.js's updateWidgetData) and just show more of
// it as there's more room: Small is a glance stat, Medium is the original workout/steps/streak
// card, Large is a fuller today-at-a-glance grid.

const BG = '#1b0a2a';
const stat = (value, label, color) => (
  <FlexWidget style={{ flexDirection: 'column' }}>
    <TextWidget text={String(value)} style={{ fontSize: 16, fontWeight: '800', color }} />
    <TextWidget text={label} style={{ fontSize: 9.5, color: '#ffffffaa' }} />
  </FlexWidget>
);

function shell(children, extra = {}) {
  return (
    <FlexWidget
      style={{
        height: 'match_parent',
        width: 'match_parent',
        flexDirection: 'column',
        justifyContent: 'space-between',
        backgroundColor: BG,
        borderRadius: 20,
        padding: 12,
        ...extra,
      }}
      clickAction="OPEN_APP"
    >
      {children}
    </FlexWidget>
  );
}

// Small (~2x2 cells): one headline number — the lifestyle score if we have one today, otherwise
// today's workout name — plus the streak underneath. Deliberately not cluttered.
export function ForgeWidgetSmall({ snapshot }) {
  const s = snapshot || {};
  const hasScore = s.score != null;
  const streak = s.streak != null ? s.streak : 0;
  return shell(
    <>
      <TextWidget text="FORGE" style={{ fontSize: 9, fontWeight: '800', color: '#FFB3CF', letterSpacing: 1.5 }} />
      <FlexWidget style={{ flexDirection: 'column', alignItems: 'center', flexGrow: 1, justifyContent: 'center' }}>
        <TextWidget
          text={hasScore ? String(s.score) : (s.workoutName || '—')}
          style={{ fontSize: hasScore ? 30 : 14, fontWeight: '800', color: '#ffffff' }}
          maxLines={hasScore ? 1 : 2}
        />
        <TextWidget text={hasScore ? 'lifestyle score' : "today's workout"} style={{ fontSize: 9, color: '#ffffffaa', marginTop: 2 }} />
      </FlexWidget>
      <TextWidget text={`${streak} day${streak === 1 ? '' : 's'} streak`} style={{ fontSize: 10, fontWeight: '700', color: '#EB1B76' }} />
    </>
  );
}

// Medium (~3x2 cells, the original widget's layout): today's workout name, steps, streak.
export function ForgeWidgetMedium({ snapshot }) {
  const s = snapshot || {};
  const workoutName = s.workoutName || 'No workout planned';
  const steps = s.steps != null ? Number(s.steps).toLocaleString() : '—';
  const streak = s.streak != null ? s.streak : 0;
  return shell(
    <>
      <TextWidget text="FORGE" style={{ fontSize: 11, fontWeight: '800', color: '#FFB3CF', letterSpacing: 2 }} />
      <TextWidget text={workoutName} style={{ fontSize: 16, fontWeight: '800', color: '#ffffff', marginTop: 4 }} maxLines={1} />
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 }}>
        {stat(steps, 'steps', '#3FA796')}
        {stat(streak, 'day streak', '#EB1B76')}
        {s.score != null ? stat(s.score, 'score', '#FFB3CF') : null}
      </FlexWidget>
    </>
  );
}

// Large (~4x3+ cells): a fuller today-at-a-glance grid — workout, then two rows of stats.
export function ForgeWidgetLarge({ snapshot }) {
  const s = snapshot || {};
  const workoutName = s.workoutName || 'No workout planned';
  const steps = s.steps != null ? Number(s.steps).toLocaleString() : '—';
  const streak = s.streak != null ? s.streak : 0;
  const move = s.moveMin != null ? `${s.moveMin}${s.moveGoal ? `/${s.moveGoal}` : ''}` : '—';
  const protein = s.proteinPct != null ? `${s.proteinPct}%` : '—';
  const water = s.waterOz != null ? `${s.waterOz}${s.waterGoal ? `/${s.waterGoal}` : ''}oz` : '—';
  const caffeine = s.caffeineMg != null ? `${s.caffeineMg}mg` : '—';
  const supp = s.suppTotal ? `${s.suppDone || 0}/${s.suppTotal}` : '—';
  return shell(
    <>
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <TextWidget text="FORGE" style={{ fontSize: 11, fontWeight: '800', color: '#FFB3CF', letterSpacing: 2 }} />
        {s.score != null ? <TextWidget text={`${s.score} score`} style={{ fontSize: 11, fontWeight: '800', color: '#ffffff' }} /> : null}
      </FlexWidget>
      <TextWidget text={workoutName} style={{ fontSize: 17, fontWeight: '800', color: '#ffffff', marginTop: 4 }} maxLines={1} />
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}>
        {stat(steps, 'steps', '#3FA796')}
        {stat(move, 'move min', '#5AA9FF')}
        {stat(protein, 'protein', '#FFB3CF')}
      </FlexWidget>
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 }}>
        {stat(water, 'water', '#5AA9FF')}
        {stat(caffeine, 'caffeine', '#E0862E')}
        {stat(supp, 'supplements', '#2fae6f')}
      </FlexWidget>
      <TextWidget text={`${streak} day${streak === 1 ? '' : 's'} streak`} style={{ fontSize: 11, fontWeight: '700', color: '#EB1B76', marginTop: 8 }} />
    </>
  );
}

// Back-compat alias, kept in case anything still imports the un-sized name directly.
export const ForgeWidget = ForgeWidgetMedium;
