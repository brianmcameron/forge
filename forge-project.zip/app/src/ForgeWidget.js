import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';

// Rendered to a native Android widget (RemoteViews) by react-native-android-widget — this
// is NOT a normal React Native screen, only the subset of components that library supports.
export function ForgeWidget({ snapshot }) {
  const s = snapshot || {};
  const workoutName = s.workoutName || 'No workout planned';
  const steps = s.steps != null ? Number(s.steps).toLocaleString() : '—';
  const streak = s.streak != null ? s.streak : 0;

  return (
    <FlexWidget
      style={{
        height: 'match_parent',
        width: 'match_parent',
        flexDirection: 'column',
        justifyContent: 'space-between',
        backgroundColor: '#1b0a2a',
        borderRadius: 20,
        padding: 14,
      }}
      clickAction="OPEN_APP"
    >
      <TextWidget text="FORGE" style={{ fontSize: 11, fontWeight: '800', color: '#FFB3CF', letterSpacing: 2 }} />
      <TextWidget
        text={workoutName}
        style={{ fontSize: 16, fontWeight: '800', color: '#ffffff', marginTop: 4 }}
        maxLines={1}
      />
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 }}>
        <FlexWidget style={{ flexDirection: 'column' }}>
          <TextWidget text={steps} style={{ fontSize: 18, fontWeight: '800', color: '#3FA796' }} />
          <TextWidget text="steps" style={{ fontSize: 10, color: '#ffffffaa' }} />
        </FlexWidget>
        <FlexWidget style={{ flexDirection: 'column' }}>
          <TextWidget text={`${streak}`} style={{ fontSize: 18, fontWeight: '800', color: '#EB1B76' }} />
          <TextWidget text={streak === 1 ? 'day streak' : 'day streak'} style={{ fontSize: 10, color: '#ffffffaa' }} />
        </FlexWidget>
      </FlexWidget>
    </FlexWidget>
  );
}
