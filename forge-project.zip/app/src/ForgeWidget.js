import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';

// Rendered to native Android widgets (RemoteViews) by react-native-android-widget — this is NOT
// a normal React Native screen, only the subset of components that library supports. Three sizes
// share one snapshot shape (see widgetData.js / App.js's updateWidgetData) and just show more of
// it as there's more room: Small is a glance stat, Medium is the original workout/steps/streak
// card, Large is a fuller today-at-a-glance grid.

const BG = '#1b0a2a';
const stat = (value, label, color) => (
  <FlexWidget style={{ flexDirection: 'column' }}>
    <TextWidget text={String(value)} style={{ fontSize: 16, fontWeight: '800', color }} />
    <TextWidget text={label} style={{ fontSize: 9.5, color: '#aaffffff' }} />
  </FlexWidget>
);

function shell(children, extra = {}) {
  return (
    <FlexWidget
      style={{
        height: 'match_parent',
        width: 'match_parent',
        flexDirection: 'column',
        justifyContent: 'space-between',
        backgroundColor: BG,
        borderRadius: 20,
        padding: 12,
        ...extra,
      }}
      clickAction="OPEN_APP"
    >
      {children}
    </FlexWidget>
  );
}

// Small (~2x2 cells): one headline number — the lifestyle score if we have one today, otherwise
// today's workout name — plus the streak underneath. Deliberately not cluttered.
export function ForgeWidgetSmall({ snapshot }) {
  const s = snapshot || {};
  const hasScore = s.score != null;
  const streak = s.streak != null ? s.streak : 0;
  return shell(
    <FlexWidget style={{ flexDirection: 'column', width: 'match_parent', height: 'match_parent', justifyContent: 'space-between' }}>
      <TextWidget text="FORGE" style={{ fontSize: 9, fontWeight: '800', color: '#FFB3CF', letterSpacing: 1.5 }} />
      <FlexWidget style={{ flexDirection: 'column', alignItems: 'center', flexGrow: 1, justifyContent: 'center' }}>
        <TextWidget
          text={hasScore ? String(s.score) : (s.workoutName || '—')}
          style={{ fontSize: hasScore ? 30 : 14, fontWeight: '800', color: '#ffffff' }}
          maxLines={hasScore ? 1 : 2}
        />
        <TextWidget text={hasScore ? 'lifestyle score' : "today's workout"} style={{ fontSize: 9, color: '#aaffffff', marginTop: 2 }} />
      </FlexWidget>
      <TextWidget text={`${streak} day${streak === 1 ? '' : 's'} streak`} style={{ fontSize: 10, fontWeight: '700', color: '#EB1B76' }} />
    </FlexWidget>
  );
}

// Medium (~3x2 cells, the original widget's layout): today's workout name, steps, streak.
export function ForgeWidgetMedium({ snapshot }) {
  const s = snapshot || {};
  const workoutName = s.workoutName || 'No workout planned';
  const steps = s.steps != null ? Number(s.steps).toLocaleString() : '—';
  const streak = s.streak != null ? s.streak : 0;
  return shell(
    <FlexWidget style={{ flexDirection: 'column', width: 'match_parent', height: 'match_parent' }}>
      <TextWidget text="FORGE" style={{ fontSize: 11, fontWeight: '800', color: '#FFB3CF', letterSpacing: 2 }} />
      <TextWidget text={workoutName} style={{ fontSize: 16, fontWeight: '800', color: '#ffffff', marginTop: 4 }} maxLines={1} />
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 }}>
        {stat(steps, 'steps', '#3FA796')}
        {stat(streak, 'day streak', '#EB1B76')}
        {s.score != null ? stat(s.score, 'score', '#FFB3CF') : null}
      </FlexWidget>
    </FlexWidget>
  );
}

// A thin horizontal progress bar built from two flexGrow-weighted FlexWidgets (filled + empty),
// since this library's flexbox subset supports flexGrow weighting but has no percentage-width
// dimension and no true progress/ring primitive. Mirrors Forge's own web `.track`/`<i style=
// "width:X%">` bars (see intakeBar() in index.html) in spirit, not pixels.
const barRow = (label, value, goal, unit, color) => {
  const g = +goal || 0;
  const filled = g ? Math.round(Math.max(0, Math.min(1, (value || 0) / g)) * 100) : 0;
  return (
    <FlexWidget style={{ flexDirection: 'column', width: 'match_parent', marginTop: 7 }}>
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', width: 'match_parent' }}>
        <TextWidget text={label} style={{ fontSize: 11, fontWeight: '700', color: '#ffffff' }} />
        <TextWidget
          text={`${Math.round(value || 0).toLocaleString()}${g ? ` / ${Math.round(g).toLocaleString()}` : ''}${unit ? ` ${unit}` : ''}`}
          style={{ fontSize: 10, color: '#aaffffff' }}
        />
      </FlexWidget>
      <FlexWidget style={{ flexDirection: 'row', width: 'match_parent', height: 6, marginTop: 3 }}>
        <FlexWidget style={{ flexGrow: filled, height: 6, backgroundColor: color }} />
        <FlexWidget style={{ flexGrow: 100 - filled, height: 6, backgroundColor: '#33ffffff' }} />
      </FlexWidget>
    </FlexWidget>
  );
};

// Large (~4x3+ cells): mirrors Home's "Today's activity" rings card layout — top: Move/Steps/
// Calories, middle: Water/Caffeine/Snacks, bottom: macros — approximated as bars since this
// widget library has no ring primitive. Kept in sync with ringsCard()/pushWidgetData() in
// index.html; see the "Widget redesign" note in project memory for the layout spec this follows.
export function ForgeWidgetLarge({ snapshot }) {
  const s = snapshot || {};
  const workoutName = s.workoutName || 'No workout planned';
  const streak = s.streak != null ? s.streak : 0;
  return shell(
    <FlexWidget style={{ flexDirection: 'column', width: 'match_parent', height: 'match_parent' }}>
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <TextWidget text="FORGE" style={{ fontSize: 11, fontWeight: '800', color: '#FFB3CF', letterSpacing: 2 }} />
        {s.score != null ? <TextWidget text={`${s.score} score`} style={{ fontSize: 11, fontWeight: '800', color: '#ffffff' }} /> : null}
      </FlexWidget>
      <TextWidget text={workoutName} style={{ fontSize: 15, fontWeight: '800', color: '#ffffff', marginTop: 3 }} maxLines={1} />

      {barRow('Move', s.moveMin, s.moveGoal, 'min', '#EB1B76')}
      {barRow('Steps', s.steps, s.stepsGoal, '', '#12B76A')}
      {barRow('Calories', s.calories, s.calorieGoal, 'kcal', '#E0862E')}

      {barRow('Water', s.waterOz, s.waterGoal, 'oz', '#5AA9FF')}
      {barRow('Caffeine', s.caffeineMg, s.caffeineCap, 'mg', '#B98A2E')}
      {barRow('Snacks', s.snackKcal, s.snackCap, 'kcal', '#E0862E')}

      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', width: 'match_parent', marginTop: 10 }}>
        {stat(s.macroP != null ? `${s.macroP}${s.macroPGoal ? `/${s.macroPGoal}` : ''}g` : '—', 'protein', '#7A5AF8')}
        {stat(s.macroC != null ? `${s.macroC}${s.macroCGoal ? `/${s.macroCGoal}` : ''}g` : '—', 'carbs', '#FF7A3D')}
        {stat(s.macroF != null ? `${s.macroF}${s.macroFGoal ? `/${s.macroFGoal}` : ''}g` : '—', 'fat', '#0EA5C4')}
      </FlexWidget>
      <TextWidget text={`${streak} day${streak === 1 ? '' : 's'} streak`} style={{ fontSize: 10, fontWeight: '700', color: '#EB1B76', marginTop: 8 }} />
    </FlexWidget>
  );
}

// Diagnostic fallback — rendered by widgetTask.js when building the real widget throws. A blank/
// transparent widget with no error gives us nothing to go on since there's no way to see this
// device's logs; this puts the actual failure reason directly on the home screen instead so it can
// be read off a screenshot. Deliberately plain (no snapshot/async dependency) so it can render even
// if the thing that broke was snapshot loading itself.
export function ForgeWidgetError({ message }) {
  return shell(
    <FlexWidget style={{ flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexGrow: 1 }}>
      <TextWidget text="Forge widget error" style={{ fontSize: 11, fontWeight: '800', color: '#FFB3CF' }} />
      <TextWidget text={String(message || 'unknown').slice(0, 160)} style={{ fontSize: 9, color: '#ffffff', marginTop: 4 }} maxLines={5} />
    </FlexWidget>
  );
}

// Back-compat alias, kept in case anything still imports the un-sized name directly.
export const ForgeWidget = ForgeWidgetMedium;
