import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async (notification) => {
    // The workout-in-progress ticker re-posts every ~20s to update its stats. It must stay
    // silent — only real reminders (and their snoozes) should alert.
    const isWorkoutTicker = notification.request.identifier === 'forge-workout';
    return isWorkoutTicker
      ? { shouldShowAlert: false, shouldPlaySound: false, shouldSetBadge: false, shouldShowBanner: false, shouldShowList: true }
      : { shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true };
  },
});

const CATEGORY = 'supplement-reminder';
let categoryReady = null;
function ensureCategory() {
  if (categoryReady) return categoryReady;
  categoryReady = Notifications.setNotificationCategoryAsync(CATEGORY, [
    { identifier: 'snooze', buttonTitle: 'Snooze 5 min', options: { opensAppToForeground: false } },
  ]);
  return categoryReady;
}

// Called once at app startup (see App.js) so a tap on "Snooze 5 min" reschedules a
// one-time follow-up notification for that same supplement, five minutes out.
export function registerSnoozeHandler() {
  return Notifications.addNotificationResponseReceivedListener(async (response) => {
    if (response.actionIdentifier !== 'snooze') return;
    const data = response.notification.request.content.data || {};
    if (!data.name) return;
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Forge · Supplement reminder (snoozed)',
          body: `${data.name} — snoozed 5 min`,
          sound: 'default',
          categoryIdentifier: CATEGORY,
          data,
          ...(Platform.OS === 'android' ? { channelId: 'supplements' } : {}),
        },
        // explicit type avoids ambiguity across expo-notifications versions about
        // whether a bare {seconds} object is treated as a time-interval trigger
        trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 300, repeats: false },
      });
    } catch (e) { /* best effort */ }
  });
}

let channelReady = null;
async function ensureChannel() {
  if (Platform.OS !== 'android') return;
  if (channelReady) return channelReady;
  channelReady = Notifications.setNotificationChannelAsync('supplements', {
    name: 'Supplement reminders',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
  });
  return channelReady;
}

function minusMinutes(hhmm, mins) {
  const [h, m] = hhmm.split(':').map(Number);
  let total = (((h * 60 + m - mins) % 1440) + 1440) % 1440;
  return { hour: Math.floor(total / 60), minute: total % 60 };
}

// Supplement reminders were removed at the user's request — Forge now only sends a
// notification when a workout is actually completed (see sendRecapNotification below).
// This function is kept as a no-op (rather than deleted) so existing calls to it stay
// harmless, and cancels anything left over from before this change.
export async function scheduleReminders(_supplements) {
  await Notifications.cancelAllScheduledNotificationsAsync();
  return { ok: true, scheduled: 0 };
}

let recapChannelReady = null;
async function ensureRecapChannel() {
  if (Platform.OS !== 'android') return;
  if (recapChannelReady) return recapChannelReady;
  recapChannelReady = Notifications.setNotificationChannelAsync('recap', {
    name: 'Workout recap',
    importance: Notifications.AndroidImportance.DEFAULT,
    sound: 'default',
  });
  return recapChannelReady;
}

// The one notification Forge still sends unprompted: a summary right after a workout is saved.
export async function sendRecapNotification({ title, body }) {
  try {
    await ensureRecapChannel();
    await Notifications.scheduleNotificationAsync({
      content: { title, body, sound: 'default', ...(Platform.OS === 'android' ? { channelId: 'recap' } : {}) },
      trigger: null,
    });
    return { ok: true };
  } catch (e) { return { ok: false }; }
}
