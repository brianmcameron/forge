import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async (notification) => {
    // The workout-in-progress ticker re-posts every ~20s to update its stats. It must stay
    // silent — only real reminders (and their snoozes) should alert.
    const isWorkoutTicker = notification.request.identifier === 'forge-workout';
    return isWorkoutTicker
      ? { shouldShowAlert: false, shouldPlaySound: false, shouldSetBadge: false, shouldShowBanner: false, shouldShowList: true }
      : { shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true };
  },
});

const CATEGORY = 'supplement-reminder';
let categoryReady = null;
function ensureCategory() {
  if (categoryReady) return categoryReady;
  categoryReady = Notifications.setNotificationCategoryAsync(CATEGORY, [
    { identifier: 'snooze', buttonTitle: 'Snooze 5 min', options: { opensAppToForeground: false } },
  ]);
  return categoryReady;
}

// Called once at app startup (see App.js) so a tap on "Snooze 5 min" reschedules a
// one-time follow-up notification for that same supplement, five minutes out.
export function registerSnoozeHandler() {
  return Notifications.addNotificationResponseReceivedListener(async (response) => {
    if (response.actionIdentifier !== 'snooze') return;
    const data = response.notification.request.content.data || {};
    if (!data.name) return;
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Forge · Supplement reminder (snoozed)',
          body: `${data.name} — snoozed 5 min`,
          sound: 'default',
          categoryIdentifier: CATEGORY,
          data,
          ...(Platform.OS === 'android' ? { channelId: 'supplements' } : {}),
        },
        // explicit type avoids ambiguity across expo-notifications versions about
        // whether a bare {seconds} object is treated as a time-interval trigger
        trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 300, repeats: false },
      });
    } catch (e) { /* best effort */ }
  });
}

let channelReady = null;
async function ensureChannel() {
  if (Platform.OS !== 'android') return;
  if (channelReady) return channelReady;
  channelReady = Notifications.setNotificationChannelAsync('supplements', {
    name: 'Supplement reminders',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
  });
  return channelReady;
}

function minusMinutes(hhmm, mins) {
  const [h, m] = hhmm.split(':').map(Number);
  let total = (((h * 60 + m - mins) % 1440) + 1440) % 1440;
  return { hour: Math.floor(total / 60), minute: total % 60 };
}

// Cancels every previously scheduled Forge reminder and reschedules from the current
// supplement list. Forge only ever schedules supplement reminders, so a full
// cancel-and-rebuild is simpler and safer than tracking individual notification ids.
export async function scheduleReminders(supplements) {
  const perm = await Notifications.getPermissionsAsync();
  let granted = perm.granted;
  if (!granted) {
    const req = await Notifications.requestPermissionsAsync();
    granted = req.granted;
  }
  await Notifications.cancelAllScheduledNotificationsAsync();
  if (!granted) return { ok: false, permission: 'denied' };
  await ensureChannel();
  await ensureCategory();
  let count = 0;
  for (const sp of supplements || []) {
    const mins = sp.remindMins ?? 15;
    for (const t of sp.times || []) {
      const { hour, minute } = minusMinutes(t, mins);
      try {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: 'Forge · Supplement reminder',
            body: `${sp.name} in ${mins} min · ${t}`,
            sound: 'default',
            categoryIdentifier: CATEGORY,
            data: { supId: sp.id, name: sp.name },
            ...(Platform.OS === 'android' ? { channelId: 'supplements' } : {}),
          },
          trigger: { type: Notifications.SchedulableTriggerInputTypes.CALENDAR, hour, minute, repeats: true },
        });
        count++;
      } catch (e) { /* skip a single bad entry rather than aborting the rest */ }
    }
  }
  return { ok: true, permission: 'granted', scheduled: count };
}
