import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true }),
});

let channelReady = null;
async function ensureChannel() {
  if (Platform.OS !== 'android') return;
  if (channelReady) return channelReady;
  channelReady = Notifications.setNotificationChannelAsync('supplements', {
    name: 'Supplement reminders',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
  });
  return channelReady;
}

function minusMinutes(hhmm, mins) {
  const [h, m] = hhmm.split(':').map(Number);
  let total = (((h * 60 + m - mins) % 1440) + 1440) % 1440;
  return { hour: Math.floor(total / 60), minute: total % 60 };
}

// Cancels every previously scheduled Forge reminder and reschedules from the current
// supplement list. Forge only ever schedules supplement reminders, so a full
// cancel-and-rebuild is simpler and safer than tracking individual notification ids.
export async function scheduleReminders(supplements) {
  const perm = await Notifications.getPermissionsAsync();
  let granted = perm.granted;
  if (!granted) {
    const req = await Notifications.requestPermissionsAsync();
    granted = req.granted;
  }
  await Notifications.cancelAllScheduledNotificationsAsync();
  if (!granted) return { ok: false, permission: 'denied' };
  await ensureChannel();
  let count = 0;
  for (const sp of supplements || []) {
    const mins = sp.remindMins ?? 15;
    for (const t of sp.times || []) {
      const { hour, minute } = minusMinutes(t, mins);
      try {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: 'Forge · Supplement reminder',
            body: `${sp.name} in ${mins} min · ${t}`,
            sound: 'default',
          },
          trigger: Platform.OS === 'android'
            ? { hour, minute, repeats: true, channelId: 'supplements' }
            : { hour, minute, repeats: true },
        });
        count++;
      } catch (e) { /* skip a single bad entry rather than aborting the rest */ }
    }
  }
  return { ok: true, permission: 'granted', scheduled: count };
}
