import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async (notification) => {
    // The workout-in-progress ticker re-posts every ~20s to update its stats. It must stay
    // silent — only real reminders (and their snoozes) should alert.
    const isWorkoutTicker = notification.request.identifier === 'forge-workout';
    return isWorkoutTicker
      ? { shouldShowAlert: false, shouldPlaySound: false, shouldSetBadge: false, shouldShowBanner: false, shouldShowList: true }
      : { shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true };
  },
});

const CATEGORY = 'supplement-reminder';
let categoryReady = null;
function ensureCategory() {
  if (categoryReady) return categoryReady;
  categoryReady = Notifications.setNotificationCategoryAsync(CATEGORY, [
    { identifier: 'snooze', buttonTitle: 'Snooze 5 min', options: { opensAppToForeground: false } },
  ]);
  return categoryReady;
}

// Called once at app startup (see App.js) so a tap on "Snooze 5 min" reschedules a
// one-time follow-up notification for that same supplement, five minutes out.
export function registerSnoozeHandler() {
  return Notifications.addNotificationResponseReceivedListener(async (response) => {
    if (response.actionIdentifier !== 'snooze') return;
    const data = response.notification.request.content.data || {};
    if (!data.name) return;
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Forge · Supplement reminder (snoozed)',
          body: `${data.name} — snoozed 5 min`,
          sound: 'default',
          categoryIdentifier: CATEGORY,
          data,
          ...(Platform.OS === 'android' ? { channelId: 'supplements' } : {}),
        },
        // explicit type avoids ambiguity across expo-notifications versions about
        // whether a bare {seconds} object is treated as a time-interval trigger
        trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 300, repeats: false },
      });
    } catch (e) { /* best effort */ }
  });
}

let channelReady = null;
async function ensureChannel() {
  if (Platform.OS !== 'android') return;
  if (channelReady) return channelReady;
  channelReady = Notifications.setNotificationChannelAsync('supplements', {
    name: 'Supplement reminders',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
  });
  return channelReady;
}

function minusMinutes(hhmm, mins) {
  const [h, m] = hhmm.split(':').map(Number);
  let total = (((h * 60 + m - mins) % 1440) + 1440) % 1440;
  return { hour: Math.floor(total / 60), minute: total % 60 };
}

const MAINTENANCE_PREFIX = 'forge-maintenance-';
const DAILY_BRIEF_ID = 'forge-daily-brief';

// Supplement reminders were removed at the user's request — Forge now only sends a
// notification when a workout is actually completed (see sendRecapNotification below),
// plus the deliberate Maintenance 3-day-before-due heads-up (see scheduleMaintenanceAlerts).
// This function is kept as a no-op for supplements (rather than deleted) so existing calls
// stay harmless, but it must NOT blow away Maintenance's scheduled alerts, so it only
// cancels notifications outside the maintenance set instead of a blanket cancel-all.
export async function scheduleReminders(_supplements) {
  try {
    const all = await Notifications.getAllScheduledNotificationsAsync();
    const toCancel = all.filter((n) => {
      const id = String(n.identifier || '');
      return !id.startsWith(MAINTENANCE_PREFIX) && id !== DAILY_BRIEF_ID;
    });
    await Promise.all(toCancel.map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier)));
    return { ok: true, scheduled: 0 };
  } catch (e) {
    return { ok: false };
  }
}

let maintenanceChannelReady = null;
async function ensureMaintenanceChannel() {
  if (Platform.OS !== 'android') return;
  if (maintenanceChannelReady) return maintenanceChannelReady;
  maintenanceChannelReady = Notifications.setNotificationChannelAsync('maintenance', {
    name: 'Maintenance reminders',
    importance: Notifications.AndroidImportance.DEFAULT,
    sound: 'default',
  });
  return maintenanceChannelReady;
}

// Deliberate exception to the "recap notification only" policy, explicitly requested by
// the user: a local push 3 days before a Maintenance item comes due. Called any time
// Maintenance items are added, edited, marked done, or removed, with the FULL current
// list — this always cancels and re-schedules from scratch so stale items never linger.
export async function scheduleMaintenanceAlerts({ items } = { items: [] }) {
  try {
    await ensureMaintenanceChannel();
    const all = await Notifications.getAllScheduledNotificationsAsync();
    const existing = all.filter((n) => String(n.identifier || '').startsWith(MAINTENANCE_PREFIX));
    await Promise.all(existing.map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier)));

    const now = new Date();
    let scheduled = 0;
    for (const item of items || []) {
      if (!item.dueDate) continue;
      const [y, m, d] = item.dueDate.split('-').map(Number);
      const due = new Date(y, (m || 1) - 1, d || 1);
      const alertAt = new Date(due);
      alertAt.setDate(alertAt.getDate() - 3);
      alertAt.setHours(9, 0, 0, 0);
      if (alertAt <= now) continue; // don't schedule alerts in the past
      await Notifications.scheduleNotificationAsync({
        identifier: `${MAINTENANCE_PREFIX}${item.id}`,
        content: {
          title: 'Forge · Coming up',
          body: `${item.name} is due in 3 days`,
          sound: 'default',
          ...(Platform.OS === 'android' ? { channelId: 'maintenance' } : {}),
        },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: alertAt },
      });
      scheduled++;
    }
    return { ok: true, scheduled };
  } catch (e) {
    return { ok: false };
  }
}

let recapChannelReady = null;
async function ensureRecapChannel() {
  if (Platform.OS !== 'android') return;
  if (recapChannelReady) return recapChannelReady;
  recapChannelReady = Notifications.setNotificationChannelAsync('recap', {
    name: 'Workout recap',
    importance: Notifications.AndroidImportance.DEFAULT,
    sound: 'default',
  });
  return recapChannelReady;
}

// The one notification Forge still sends unprompted: a summary right after a workout is saved.
export async function sendRecapNotification({ title, body }) {
  try {
    await ensureRecapChannel();
    await Notifications.scheduleNotificationAsync({
      content: { title, body, sound: 'default', ...(Platform.OS === 'android' ? { channelId: 'recap' } : {}) },
      trigger: null,
    });
    return { ok: true };
  } catch (e) { return { ok: false }; }
}

// --- Daily brief ("accountability partner") ---
// A recurring local notification at a user-set time every day. Robustness notes: expo-notifications'
// Android module registers its own boot receiver that re-arms scheduled/recurring triggers after a
// device reboot, so this survives a restart without any custom native code here. On top of that,
// scheduleDailyBrief() is called again (idempotently — same identifier, so it just replaces itself)
// on every app resume/launch from the web layer, which self-heals if the OS ever drops it for some
// other reason (permission reset, channel deleted, etc.) rather than relying on a single schedule call.
let briefChannelReady = null;
async function ensureBriefChannel() {
  if (Platform.OS !== 'android') return;
  if (briefChannelReady) return briefChannelReady;
  briefChannelReady = Notifications.setNotificationChannelAsync('daily-brief', {
    name: 'Daily brief',
    importance: Notifications.AndroidImportance.HIGH,
    sound: 'default',
  });
  return briefChannelReady;
}

export async function scheduleDailyBrief({ hour, minute, enabled }) {
  try {
    await Notifications.cancelScheduledNotificationAsync(DAILY_BRIEF_ID).catch(() => {});
    if (enabled === false) return { ok: true, scheduled: false };
    const perm = await Notifications.requestPermissionsAsync();
    if (!perm.granted) return { ok: false, reason: 'permission-denied' };
    await ensureBriefChannel();
    await Notifications.scheduleNotificationAsync({
      identifier: DAILY_BRIEF_ID,
      content: {
        title: 'Forge · Your daily brief',
        body: "Today's 2-minute plan is ready — tap to see it.",
        sound: 'default',
        data: { type: 'dailyBrief' },
        ...(Platform.OS === 'android' ? { channelId: 'daily-brief' } : {}),
      },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour: +hour || 7, minute: +minute || 0 },
    });
    return { ok: true, scheduled: true };
  } catch (e) {
    return { ok: false, reason: e?.message || 'schedule failed' };
  }
}

// Called once at app startup (see App.js) so tapping the daily-brief notification — whether Forge
// was backgrounded or fully killed — opens the brief instead of just foregrounding the app.
export function registerDailyBriefHandler(onOpen) {
  return Notifications.addNotificationResponseReceivedListener((response) => {
    const data = response.notification.request.content.data || {};
    if (data.type === 'dailyBrief') onOpen();
  });
}

// Cold-start case: the app process wasn't running at all when the notification was tapped, so
// there was no listener yet to catch it — check whether THIS launch was caused by that tap.
export async function wasLaunchedFromDailyBrief() {
  try {
    const last = await Notifications.getLastNotificationResponseAsync();
    const data = last?.notification?.request?.content?.data || {};
    return data.type === 'dailyBrief';
  } catch (e) { return false; }
}
