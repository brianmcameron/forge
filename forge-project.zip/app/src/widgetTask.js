import React from 'react';
import { ForgeWidgetSmall, ForgeWidgetMedium, ForgeWidgetLarge } from './ForgeWidget';
import { loadWidgetSnapshot } from './widgetData';

// Registered as the app's widget task handler (see index.js). Android calls this — even
// while Forge itself isn't open — whenever a widget needs to be drawn or redrawn:
// first added to the home screen, resized, periodically refreshed by the OS, or tapped.
// There are 3 separate widget definitions now (app.json), one per size, each its own pick in
// the OS's widget list — widgetInfo.widgetName tells us which one Android is asking about.
const WIDGETS = {
  'Forge — Small': ForgeWidgetSmall,
  'Forge — Medium': ForgeWidgetMedium,
  'Forge — Large': ForgeWidgetLarge,
};

export async function widgetTaskHandler(props) {
  const snapshot = await loadWidgetSnapshot();
  const widgetInfo = props.widgetInfo;
  const Widget = WIDGETS[widgetInfo && widgetInfo.widgetName] || ForgeWidgetMedium;

  switch (props.widgetAction) {
    case 'WIDGET_ADDED':
    case 'WIDGET_UPDATE':
    case 'WIDGET_RESIZED':
      props.renderWidget(<Widget snapshot={snapshot} />);
      break;
    case 'WIDGET_DELETED':
      // nothing to clean up — the snapshot is small and shared across every placed instance
      break;
    case 'WIDGET_CLICK':
      // clickAction="OPEN_APP" on the widget already handles opening Forge; nothing more to do here
      break;
    default:
      break;
  }
}
