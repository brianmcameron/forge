import React from 'react';
import { ForgeWidgetSmall, ForgeWidgetMedium, ForgeWidgetLarge, ForgeWidgetError } from './ForgeWidget';
import { loadWidgetSnapshot, loadWidgetDayOffset, saveWidgetDayOffset } from './widgetData';

// Registered as the app's widget task handler (see index.js). Android calls this — even
// while Forge itself isn't open — whenever a widget needs to be drawn or redrawn:
// first added to the home screen, resized, periodically refreshed by the OS, or tapped.
// There are 3 separate widget definitions now (app.json), one per size, each its own pick in
// the OS's widget list — widgetInfo.widgetName tells us which one Android is asking about.
// These keys are each widget's app.json "name" (ForgeSmall/Medium/Large) — that field becomes
// an Android resource identifier under the hood, so it has to stay plain letters/digits, no
// spaces or punctuation; app.json's "label" is the pretty text shown in the OS widget picker.
const WIDGETS = {
  ForgeSmall: ForgeWidgetSmall,
  ForgeMedium: ForgeWidgetMedium,
  ForgeLarge: ForgeWidgetLarge,
};

export async function widgetTaskHandler(props) {
  const widgetInfo = props.widgetInfo;
  const Widget = WIDGETS[widgetInfo && widgetInfo.widgetName] || ForgeWidgetMedium;

  try {
    switch (props.widgetAction) {
      case 'WIDGET_ADDED':
      case 'WIDGET_UPDATE':
      case 'WIDGET_RESIZED': {
        const snapshot = await loadWidgetSnapshot();
        const dayOffset = await loadWidgetDayOffset();
        props.renderWidget(<Widget snapshot={snapshot} dayOffset={dayOffset} />);
        break;
      }
      case 'WIDGET_DELETED':
        // nothing to clean up — the snapshot is small and shared across every placed instance
        break;
      case 'WIDGET_CLICK': {
        // clickAction="OPEN_APP" on the widget shell handles opening Forge — that's every click
        // except the Large widget's day-nav arrows, which carry their own clickAction/
        // clickActionData (see barRow's dayNav arrows in ForgeWidget.js) and must be handled here
        // WITHOUT opening the app, entirely by re-rendering from the cached snapshot.days.
        const action = props.clickAction;
        if (action === 'DAY_PREV' || action === 'DAY_NEXT') {
          const snapshot = await loadWidgetSnapshot();
          const maxOffset = snapshot && Array.isArray(snapshot.days) ? snapshot.days.length - 1 : 0;
          let offset = await loadWidgetDayOffset();
          offset = action === 'DAY_PREV' ? Math.min(maxOffset, offset + 1) : Math.max(0, offset - 1);
          await saveWidgetDayOffset(offset);
          props.renderWidget(<Widget snapshot={snapshot} dayOffset={offset} />);
        }
        break;
      }
      default:
        break;
    }
  } catch (err) {
    // Temporary diagnostic: a widget that renders blank with no error gives us nothing to go on
    // since there's no way to see this device's logs remotely. Surface the actual failure reason
    // directly in the widget itself instead, so it can be read straight off a screenshot.
    try { props.renderWidget(<ForgeWidgetError message={(err && err.message) || String(err)} />); } catch (e2) { /* truly nothing we can do */ }
  }
}
