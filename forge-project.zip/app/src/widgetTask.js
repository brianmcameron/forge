import React from 'react';
import { ForgeWidget } from './ForgeWidget';
import { loadWidgetSnapshot } from './widgetData';

// Registered as the app's widget task handler (see index.js). Android calls this — even
// while Forge itself isn't open — whenever the widget needs to be drawn or redrawn:
// first added to the home screen, resized, periodically refreshed by the OS, or tapped.
export async function widgetTaskHandler(props) {
  const snapshot = await loadWidgetSnapshot();
  const widgetInfo = props.widgetInfo;

  switch (props.widgetAction) {
    case 'WIDGET_ADDED':
    case 'WIDGET_UPDATE':
    case 'WIDGET_RESIZED':
      props.renderWidget(<ForgeWidget snapshot={snapshot} />);
      break;
    case 'WIDGET_DELETED':
      // nothing to clean up — the snapshot is small and shared if another widget instance exists
      break;
    case 'WIDGET_CLICK':
      // clickAction="OPEN_APP" on the widget already handles opening Forge; nothing more to do here
      break;
    default:
      break;
  }
}
