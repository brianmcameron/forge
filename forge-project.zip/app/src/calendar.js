import { getAccessToken } from './googleAuth';

// Read-only pull of today's events from the signed-in user's PRIMARY Google Calendar only.
// One-way (Google → Forge) — Forge never writes to the calendar. Mirrors drive.js's auth-retry
// pattern. Needs the calendar.readonly scope (see googleAuth.js); a user whose grant doesn't
// include it yet gets a 401/403 here — reconnectGoogleAccess() (wired to the "Reconnect calendar
// access" button shown for reason:'no-access') is what actually fixes that, not a sign-out/in.
const API = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';

async function authedFetch(url, retried = false) {
  const token = await getAccessToken();
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (res.status === 401 && !retried) return authedFetch(url, true);
  return res;
}

export async function calendarToday() {
  // debug always travels back with the result (success AND failure) — a report of "it says it
  // synced but shows nothing" has historically been impossible to diagnose without device logs,
  // since an empty-but-successful response looks identical to a real empty day. This surfaces the
  // exact local window queried, which calendar/account Google actually answered for (its display
  // name + email, which catches "signed into the wrong account" or "primary isn't what I think it
  // is" instantly), and the raw vs. filtered item counts (catches an over-aggressive filter).
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const end = new Date(); end.setHours(23, 59, 59, 999);
  const debug = { windowStart: start.toString(), windowEnd: end.toString() };
  try {
    const q = new URLSearchParams({
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
      singleEvents: 'true',
      orderBy: 'startTime',
      maxResults: '25',
    });
    const res = await authedFetch(`${API}?${q.toString()}`);
    if (res.status === 401 || res.status === 403) {
      return { ok: false, reason: 'no-access', message: 'Forge needs calendar access — tap Reconnect below', debug };
    }
    if (!res.ok) return { ok: false, reason: 'http-' + res.status, debug };
    const j = await res.json();
    debug.calendarSummary = j.summary || null; // the actual calendar Google answered for (name/email)
    debug.timeZone = j.timeZone || null;
    debug.rawCount = (j.items || []).length;
    const items = (j.items || [])
      .filter((e) => e.status !== 'cancelled' && (e.summary || e.start))
      .map((e) => ({
        id: e.id,
        title: e.summary || '(no title)',
        allDay: !!(e.start && e.start.date && !e.start.dateTime),
        start: e.start ? (e.start.dateTime || e.start.date) : null,
        end: e.end ? (e.end.dateTime || e.end.date) : null,
      }));
    debug.filteredCount = items.length;
    return { ok: true, items, debug };
  } catch (e) {
    return { ok: false, reason: 'error', message: e?.message || 'Calendar fetch failed', debug };
  }
}

// Lifestyle OS V2 Phase 2: week-range pull for Weekly Forge / calendar-intelligence — same
// read-only, single-calendar approach as calendarToday() above, just a wider [today, +6 days]
// window, grouped by local date key so the web layer can reason about per-day busy-minutes
// across the week without a separate call per day.
export async function calendarWeek() {
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const end = new Date(start); end.setDate(end.getDate() + 7); end.setMilliseconds(-1); // end of day 6 days out
  const debug = { windowStart: start.toString(), windowEnd: end.toString() };
  const dayKey = (d) => {
    const dt = new Date(d);
    return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
  };
  try {
    const q = new URLSearchParams({
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
      singleEvents: 'true',
      orderBy: 'startTime',
      maxResults: '120',
    });
    const res = await authedFetch(`${API}?${q.toString()}`);
    if (res.status === 401 || res.status === 403) {
      return { ok: false, reason: 'no-access', message: 'Forge needs calendar access — tap Reconnect below', debug };
    }
    if (!res.ok) return { ok: false, reason: 'http-' + res.status, debug };
    const j = await res.json();
    debug.calendarSummary = j.summary || null;
    debug.timeZone = j.timeZone || null;
    debug.rawCount = (j.items || []).length;
    const byDay = {};
    (j.items || [])
      .filter((e) => e.status !== 'cancelled' && (e.summary || e.start))
      .forEach((e) => {
        const allDay = !!(e.start && e.start.date && !e.start.dateTime);
        const startIso = e.start ? (e.start.dateTime || e.start.date) : null;
        const endIso = e.end ? (e.end.dateTime || e.end.date) : null;
        if (!startIso) return;
        const k = dayKey(startIso);
        if (!byDay[k]) byDay[k] = [];
        byDay[k].push({ id: e.id, title: e.summary || '(no title)', allDay, start: startIso, end: endIso });
      });
    debug.filteredCount = Object.values(byDay).reduce((a, arr) => a + arr.length, 0);
    return { ok: true, byDay, debug };
  } catch (e) {
    return { ok: false, reason: 'error', message: e?.message || 'Calendar fetch failed', debug };
  }
}
