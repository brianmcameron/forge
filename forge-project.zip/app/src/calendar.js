import { getAccessToken } from './googleAuth';

// Read-only pull of today's events from the signed-in user's PRIMARY Google Calendar only.
// One-way (Google → Forge) — Forge never writes to the calendar. Mirrors drive.js's auth-retry
// pattern. Needs the calendar.readonly scope (see googleAuth.js); a user signed in before that
// scope existed will get a 401/403 here until they sign out and back in once.
const API = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';

async function authedFetch(url, retried = false) {
  const token = await getAccessToken();
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (res.status === 401 && !retried) return authedFetch(url, true);
  return res;
}

export async function calendarToday() {
  try {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const end = new Date(); end.setHours(23, 59, 59, 999);
    const q = new URLSearchParams({
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
      singleEvents: 'true',
      orderBy: 'startTime',
      maxResults: '25',
    });
    const res = await authedFetch(`${API}?${q.toString()}`);
    if (res.status === 401 || res.status === 403) {
      return { ok: false, reason: 'no-access', message: 'Sign out and back in to grant Forge calendar access' };
    }
    if (!res.ok) return { ok: false, reason: 'http-' + res.status };
    const j = await res.json();
    const items = (j.items || [])
      .filter((e) => e.status !== 'cancelled' && (e.summary || e.start))
      .map((e) => ({
        id: e.id,
        title: e.summary || '(no title)',
        allDay: !!(e.start && e.start.date && !e.start.dateTime),
        start: e.start ? (e.start.dateTime || e.start.date) : null,
        end: e.end ? (e.end.dateTime || e.end.date) : null,
      }));
    return { ok: true, items };
  } catch (e) {
    return { ok: false, reason: 'error', message: e?.message || 'Calendar fetch failed' };
  }
}
