import { getAccessToken } from './googleAuth';

// Read-only pull of events across every calendar the signed-in user has selected/visible in their
// own Google Calendar (not just primary — see listCalendars() below, added to fix root cause #2
// of the 2026-10-03 calendar-ingestion trace: Forge used to hardcode the primary calendar only, so
// anything on a secondary/shared/work calendar was invisible with nothing disclosing that).
// One-way (Google → Forge) — Forge never writes to the calendar. Mirrors drive.js's auth-retry
// pattern. Needs the calendar.readonly scope (see googleAuth.js); a user whose grant doesn't
// include it yet gets a 401/403 here — reconnectGoogleAccess() (wired to the "Reconnect calendar
// access" button shown for reason:'no-access') is what actually fixes that, not a sign-out/in.
const CALENDAR_LIST_API = 'https://www.googleapis.com/calendar/v3/users/me/calendarList';
const eventsApiFor = (calendarId) => `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`;

async function authedFetch(url, retried = false) {
  const token = await getAccessToken();
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (res.status === 401 && !retried) return authedFetch(url, true);
  return res;
}

// Returns every calendar the user has selected/visible (mirrors what they'd actually see in their
// own Google Calendar app) — primary plus any secondary/shared calendars, excluding ones they've
// deliberately hidden (selected:false) or deleted. Returns null on failure so callers can fall
// back to primary-only rather than failing the whole sync over calendar-list discovery alone.
async function listCalendars() {
  try {
    const res = await authedFetch(`${CALENDAR_LIST_API}?minAccessRole=freeBusyReader&maxResults=250`);
    if (!res.ok) return null;
    const j = await res.json();
    const cals = (j.items || []).filter((c) => c.selected !== false && !c.deleted)
      .map((c) => ({ id: c.id, summary: c.summary || c.id, primary: !!c.primary }));
    return cals.length ? cals : null;
  } catch (e) { return null; }
}

// Fetches one calendar's events for [timeMin,timeMax) and normalizes them. Never throws — a
// single calendar's failure is reported back as {error} so the caller can merge the calendars
// that DID succeed instead of losing the whole pull over one bad one (e.g. a shared calendar
// whose owner revoked access).
async function eventsForCalendar(calendarId, timeMin, timeMax, maxResults) {
  try {
    const q = new URLSearchParams({ timeMin, timeMax, singleEvents: 'true', orderBy: 'startTime', maxResults: String(maxResults) });
    const res = await authedFetch(`${eventsApiFor(calendarId)}?${q.toString()}`);
    if (res.status === 401 || res.status === 403) return { authError: true };
    if (!res.ok) return { error: 'http-' + res.status };
    const j = await res.json();
    const items = (j.items || [])
      .filter((e) => e.status !== 'cancelled' && (e.summary || e.start))
      .map((e) => ({
        id: e.id,
        title: e.summary || '(no title)',
        allDay: !!(e.start && e.start.date && !e.start.dateTime),
        start: e.start ? (e.start.dateTime || e.start.date) : null,
        end: e.end ? (e.end.dateTime || e.end.date) : null,
      }));
    return { timeZone: j.timeZone || null, rawCount: (j.items || []).length, items };
  } catch (e) { return { error: e?.message || 'fetch failed' }; }
}

export async function calendarToday() {
  // debug always travels back with the result (success AND failure) — a report of "it says it
  // synced but shows nothing" has historically been impossible to diagnose without device logs,
  // since an empty-but-successful response looks identical to a real empty day. This surfaces the
  // exact local window queried, which calendars were actually queried (name + per-calendar counts
  // or errors — catches both "signed into the wrong account" and "only primary was ever checked"),
  // and the raw vs. filtered item counts (catches an over-aggressive filter).
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const end = new Date(); end.setHours(23, 59, 59, 999);
  const debug = { windowStart: start.toString(), windowEnd: end.toString() };
  try {
    const cals = (await listCalendars()) || [{ id: 'primary', summary: 'primary' }];
    debug.calendarsQueried = cals.map((c) => c.summary);
    const results = await Promise.all(cals.map((c) => eventsForCalendar(c.id, start.toISOString(), end.toISOString(), 25)));
    // Every calendar queried came back with an auth error (401/403) — not just the single-primary
    // fallback case. A token that's lost/never had calendar.readonly scope can still let
    // listCalendars() itself succeed (calendarList is a different scope check than events), so this
    // must be checked for N calendars, not just the N===1 fallback case, or the actionable
    // "Reconnect calendar access" button never shows and the user just sees a generic error.
    if (results.length > 0 && results.every((r) => r.authError)) {
      return { ok: false, reason: 'no-access', message: 'Forge needs calendar access — tap Reconnect below', debug };
    }
    const items = [];
    let rawCount = 0;
    debug.perCalendar = cals.map((c, i) => {
      const r = results[i];
      if (r.error || r.authError) return { calendar: c.summary, error: r.error || 'no-access' };
      rawCount += r.rawCount || 0;
      items.push(...r.items.map((e) => ({ ...e, calendar: c.summary })));
      return { calendar: c.summary, count: r.items.length };
    });
    debug.rawCount = rawCount;
    debug.filteredCount = items.length;
    items.sort((a, b) => String(a.start).localeCompare(String(b.start)));
    // Every calendar queried failed outright (none merely came back empty) — that's a real sync
    // failure, not an honestly-empty day, so it must not be reported as ok:true with zero items.
    if (items.length === 0 && debug.perCalendar.every((p) => p.error)) {
      return { ok: false, reason: 'error', message: 'Couldn’t reach any connected calendar', debug };
    }
    return { ok: true, items, debug };
  } catch (e) {
    return { ok: false, reason: 'error', message: e?.message || 'Calendar fetch failed', debug };
  }
}

// Lifestyle OS V2 Phase 2: week-range pull for Weekly Forge / calendar-intelligence — same
// read-only, single-calendar approach as calendarToday() above, just a wider [today, +6 days]
// window, grouped by local date key so the web layer can reason about per-day busy-minutes
// across the week without a separate call per day.
export async function calendarWeek() {
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const end = new Date(start); end.setDate(end.getDate() + 7); end.setMilliseconds(-1); // end of day 6 days out
  const debug = { windowStart: start.toString(), windowEnd: end.toString() };
  const dayKey = (d) => {
    const dt = new Date(d);
    return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
  };
  try {
    const cals = (await listCalendars()) || [{ id: 'primary', summary: 'primary' }];
    debug.calendarsQueried = cals.map((c) => c.summary);
    const results = await Promise.all(cals.map((c) => eventsForCalendar(c.id, start.toISOString(), end.toISOString(), 120)));
    if (results.length > 0 && results.every((r) => r.authError)) {
      return { ok: false, reason: 'no-access', message: 'Forge needs calendar access — tap Reconnect below', debug };
    }
    const byDay = {};
    let rawCount = 0;
    debug.perCalendar = cals.map((c, i) => {
      const r = results[i];
      if (r.error || r.authError) return { calendar: c.summary, error: r.error || 'no-access' };
      rawCount += r.rawCount || 0;
      r.items.forEach((e) => {
        if (!e.start) return;
        const k = dayKey(e.start);
        if (!byDay[k]) byDay[k] = [];
        byDay[k].push({ ...e, calendar: c.summary });
      });
      return { calendar: c.summary, count: r.items.length };
    });
    debug.rawCount = rawCount;
    debug.filteredCount = Object.values(byDay).reduce((a, arr) => a + arr.length, 0);
    if (debug.filteredCount === 0 && debug.perCalendar.every((p) => p.error)) {
      return { ok: false, reason: 'error', message: 'Couldn’t reach any connected calendar', debug };
    }
    return { ok: true, byDay, debug };
  } catch (e) {
    return { ok: false, reason: 'error', message: e?.message || 'Calendar fetch failed', debug };
  }
}
