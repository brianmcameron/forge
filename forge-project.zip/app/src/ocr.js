import TextRecognition from '@react-native-ml-kit/text-recognition';

// On-device text recognition (Google ML Kit, bundled in the APK — no network call, no per-scan
// cost, works offline) for the nutrition-label and supplement-bottle photo scans. Kept as a thin
// wrapper so App.js's handler and any future caller don't need to know the library's own shape.
export async function recognizeTextFromPhoto(uri) {
  if (!uri) return { ok: false, text: '' };
  try {
    const result = await TextRecognition.recognize(uri);
    return { ok: true, text: (result && result.text) || '' };
  } catch (e) {
    return { ok: false, text: '', message: (e && e.message) || 'Text recognition failed' };
  }
}
