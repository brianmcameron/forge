import { registerRootComponent } from 'expo';
import { registerWidgetTaskHandler } from 'react-native-android-widget';
import App from './App';
import { widgetTaskHandler } from './src/widgetTask';

// registerRootComponent calls AppRegistry.registerComponent('main', () => App) under the hood,
// and also handles the Expo Go vs standalone-app distinction — this replaces the default
// expo/AppEntry so we can also register the widget task handler alongside it.
registerRootComponent(App);
registerWidgetTaskHandler(widgetTaskHandler);
