import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, BackHandler, Linking, Share, StatusBar, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import forgeHtml from './src/forgeHtml';
import { TRENDS_URL, NUTRIENT_REF_URL } from './src/config';
import { initFoodDb, searchFoods } from './src/foodDb';
import { healthStatus, healthConnect, healthToday, healthExerciseSessions, healthHistory } from './src/health';
import { scheduleReminders, registerSnoozeHandler, sendRecapNotification, scheduleMaintenanceAlerts, scheduleDailyBrief, registerDailyBriefHandler, wasLaunchedFromDailyBrief } from './src/reminders';
import { googleSignIn, googleSignOut, reconnectGoogleAccess } from './src/googleAuth';
import { driveBackupNow, driveRestore } from './src/drive';
import { calendarToday, calendarWeek } from './src/calendar';
import { updateWorkoutNotification, clearWorkoutNotification } from './src/workoutNotify';
import BarcodeScanner from './src/BarcodeScanner';
import PhotoCapture from './src/PhotoCapture';
import { recognizeTextFromPhoto } from './src/ocr';
import { requestWidgetUpdate } from 'react-native-android-widget';
import { saveWidgetSnapshot, resetWidgetDayOffset } from './src/widgetData';
import { ForgeWidgetSmall, ForgeWidgetMedium, ForgeWidgetLarge, ForgeWidgetError } from './src/ForgeWidget';

// One entry per size defined in app.json — every placed instance of every size refreshes
// together whenever the web layer pushes new data. Keys are each widget's app.json "name"
// (a plain identifier, not the "label" shown to the user — see widgetTask.js for why).
const WIDGET_COMPONENTS = {
  ForgeSmall: ForgeWidgetSmall,
  ForgeMedium: ForgeWidgetMedium,
  ForgeLarge: ForgeWidgetLarge,
};

// Point 4 (AI_TIERS, index.html): which real OpenAI model backs each tier. A named lookup table,
// not a string buried in the fetch call below, so a model swap is a one-line edit here — never a
// vendor/model name hardcoded per call site. Tiers 1/2 share a cheap model; tier 3 (Weekly Forge,
// complex Ask Forge) gets the stronger model since it runs rarely (see AI_TIERS comments).
const OPENAI_MODELS_BY_TIER = {
  1: 'gpt-4o-mini',
  2: 'gpt-4o-mini',
  3: 'gpt-4o',
};
const OPENAI_DEFAULT_MODEL = 'gpt-4o-mini';

// Approximate OpenAI pricing, USD per 1K tokens (prompt/completion) — current as of this pass,
// NOT fetched live. These drift as OpenAI reprices models; revisit if estCost looks obviously off.
const OPENAI_PRICING_PER_1K = {
  'gpt-4o-mini': { prompt: 0.00015, completion: 0.0006 },
  'gpt-4o': { prompt: 0.0025, completion: 0.01 },
};

// A few sentences per request type — kept deliberately short (hard product requirement: never
// resend a big spec every call). Mirrors AI_REQUEST_TYPES in index.html; if a type is missing here
// it falls back to a generic instruction below rather than failing.
const OPENAI_SYSTEM_PROMPTS = {
  askForge: "You are Ask Forge, a calm assistant inside a personal life-tracking app called Forge. You'll be given compact structured context about the user's day/week and a question. Answer briefly and concretely using only the given context. If the context doesn't contain the answer, say so plainly — never invent data.",
  rightNowExplain: 'Given the structured facts below, write one short, warm sentence explaining why this is a good next action right now. Do not restate every fact — just the key reason.',
  dailyForgeExplain: "Given the structured facts below about the user's day, write a brief, warm 1-2 sentence summary highlighting what matters most. Do not restate every fact.",
  nutritionInterpretation: 'Given the structured nutrition facts below, write one short, practical sentence interpreting what they mean for the rest of the day.',
  recommendationExplain: 'Given the structured facts below, write one short sentence explaining the reasoning behind this recommendation.',
  weeklyForgeExplain: "Given the structured facts below about the user's week, write a brief, encouraging summary (2-3 sentences) of progress and what to focus on next.",
  classification: 'Classify the given text as briefly as possible — respond with just the label, no explanation.',
  notificationWording: 'Write a short, friendly notification message (one sentence) based on the structured facts below.',
};
const OPENAI_FALLBACK_SYSTEM_PROMPT = 'You are a terse assistant inside a personal life-tracking app called Forge. Use only the given structured context. Answer as briefly as possible.';

const DARK = '#1b0a2a'; // matches the launch animation

async function fetchTrends() {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(TRENDS_URL + '?t=' + Date.now(), { signal: ctl.signal });
    if (!r.ok) throw new Error('http ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

async function fetchNutrientRef() {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(NUTRIENT_REF_URL + '?t=' + Date.now(), { signal: ctl.signal });
    if (!r.ok) throw new Error('http ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

const HANDLERS = {
  foodSearch: ({ q, limit }) => searchFoods(String(q || ''), Math.min(+limit || 24, 40)),
  trends: () => fetchTrends(),
  nutrientRef: () => fetchNutrientRef(),
  openUrl: async ({ url }) => { if (/^https?:\/\//.test(String(url))) await Linking.openURL(url); return {}; },
  shareBackup: async ({ text, name }) => { await Share.share({ message: String(text), title: String(name || 'forge-backup.json') }); return {}; },
  healthStatus: () => healthStatus(),
  healthConnect: () => healthConnect(),
  healthToday: () => healthToday(),
  healthSessions: ({ days }) => healthExerciseSessions(days || 7),
  healthHistory: ({ days }) => healthHistory(days || 7),
  scheduleReminders: ({ supplements }) => scheduleReminders(supplements || []),
  scheduleMaintenanceAlerts: ({ items }) => scheduleMaintenanceAlerts({ items: items || [] }),
  sendRecapNotification: ({ title, body }) => sendRecapNotification({ title, body }),
  scheduleDailyBrief: ({ hour, minute, enabled }) => scheduleDailyBrief({ hour, minute, enabled }),
  calendarToday: () => calendarToday(),
  calendarWeek: () => calendarWeek(),
  // Lifestyle OS V2 Phase 5 (Ask Forge): real OpenAI call (the user confirmed direct client-side
  // calls are fine for this personal app, same pattern as the Kroger proxyFetch below, and chose
  // OpenAI specifically). The web layer (ForgeAIProvider._callDirect in index.html) is the only
  // caller, and the shape returned here flows straight into ForgeAIUsageTracker.recordCall() and
  // askForge() — see the shape notes in index.html's ForgeAIRouter.request()/askForge().
  aiAsk: async ({ apiKey, provider, type, tier, maxTokens, context }) => {
    if (provider !== 'openai') {
      return { ok: false, message: 'Only OpenAI is wired up right now.', model: null, inputTokens: 0, outputTokens: 0, estCost: 0 };
    }
    if (!apiKey || !String(apiKey).trim()) {
      return { ok: false, message: 'No API key connected yet.', model: null, inputTokens: 0, outputTokens: 0, estCost: 0 };
    }
    const model = OPENAI_MODELS_BY_TIER[tier] || OPENAI_DEFAULT_MODEL;
    const systemPrompt = OPENAI_SYSTEM_PROMPTS[type] || OPENAI_FALLBACK_SYSTEM_PROMPT;
    // context already carries `question` for askForge (see ForgeContextRetrieval.forAskForge /
    // ForgeContextBuilder.forType('askForge',...) in index.html) — no separate question field
    // needed here, the whole bounded context object is just JSON-stringified as the user turn.
    const userContent = JSON.stringify(context || {});
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userContent },
          ],
          max_tokens: maxTokens || 200,
        }),
        signal: ctl.signal,
      });
      const data = await r.json().catch(() => null);
      if (!r.ok || !data) {
        const message = (data && data.error && data.error.message) || `OpenAI request failed (HTTP ${r.status}).`;
        return { ok: false, message, model, inputTokens: 0, outputTokens: 0, estCost: 0 };
      }
      const answer = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
      const inputTokens = (data.usage && data.usage.prompt_tokens) || 0;
      const outputTokens = (data.usage && data.usage.completion_tokens) || 0;
      const pricing = OPENAI_PRICING_PER_1K[model] || OPENAI_PRICING_PER_1K[OPENAI_DEFAULT_MODEL];
      const estCost = (inputTokens / 1000) * pricing.prompt + (outputTokens / 1000) * pricing.completion;
      return {
        ok: true,
        result: { answer: answer.trim() },
        model,
        inputTokens,
        outputTokens,
        cachedTokens: 0,
        estCost,
      };
    } catch (e) {
      const message = e && e.name === 'AbortError' ? 'OpenAI request timed out.' : String((e && e.message) || e);
      return { ok: false, message, model, inputTokens: 0, outputTokens: 0, estCost: 0 };
    } finally {
      clearTimeout(t);
    }
  },
  // Generic passthrough fetch for APIs that don't support browser-origin CORS (the Kroger grocery
  // price check needs this for its OAuth token endpoint) — a plain server-side-style fetch from the
  // native app has no CORS restriction at all, unlike fetch() called from inside the WebView.
  proxyFetch: async ({ url, method, headers, body }) => {
    if (!/^https:\/\//.test(String(url || ''))) return { ok: false, status: 0 };
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await fetch(url, { method: method || 'GET', headers: headers || {}, body: body || undefined, signal: ctl.signal });
      const text = await r.text();
      let json = null; try { json = JSON.parse(text); } catch (_) {}
      return { ok: r.ok, status: r.status, json };
    } catch (e) {
      return { ok: false, status: 0 };
    } finally { clearTimeout(t); }
  },
  googleSignIn: () => googleSignIn(),
  googleSignOut: () => googleSignOut(),
  googleReconnectCalendar: () => reconnectGoogleAccess(),
  driveBackupNow: ({ json }) => driveBackupNow(json),
  driveRestore: () => driveRestore(),
  updateWidgetData: async (snapshot) => {
    await saveWidgetSnapshot(snapshot);
    // A fresh snapshot always resets day-nav back to today — otherwise a widget left showing
    // 3 days ago would silently keep showing 3-days-ago's numbers relabeled as if they were fresh.
    await resetWidgetDayOffset();
    // Update every size — each is its own placed instance (or none at all), so a failure on
    // one (nothing of that size on the home screen) shouldn't stop the others from refreshing.
    // Temporary diagnostic: same as widgetTask.js's headless-task path, a failed update here was
    // previously swallowed silently by allSettled with nothing visible to show for it — now a
    // failure puts the actual error message on that widget instead of leaving it blank.
    const results = await Promise.allSettled(Object.entries(WIDGET_COMPONENTS).map(([widgetName, Widget]) =>
      requestWidgetUpdate({ widgetName, renderWidget: () => <Widget snapshot={snapshot} dayOffset={0} /> })
    ));
    const widgetNames = Object.keys(WIDGET_COMPONENTS);
    await Promise.allSettled(results.map((r, i) => {
      if (r.status !== 'rejected') return Promise.resolve();
      const widgetName = widgetNames[i];
      const message = (r.reason && r.reason.message) || String(r.reason);
      return requestWidgetUpdate({ widgetName, renderWidget: () => <ForgeWidgetError message={message} /> }).catch(() => {});
    }));
    return {};
  },
  workoutNotifyUpdate: ({ title, body }) => updateWorkoutNotification({ title, body }),
  workoutNotifyClear: () => clearWorkoutNotification(),
  exit: async () => { BackHandler.exitApp(); return {}; },
};

function Shell() {
  const web = useRef(null);
  const insets = useSafeAreaInsets();
  const [chrome, setChrome] = useState({ bg: DARK, dark: true });
  const [scanning, setScanning] = useState(false);
  const scanResolver = useRef(null);
  const [photoCapture, setPhotoCapture] = useState(null); // { hint } while a label/bottle photo scan is active
  const photoResolver = useRef(null);
  const pageReadyRef = useRef(false);
  const pendingBriefRef = useRef(false);

  useEffect(() => { initFoodDb(); }, []);
  useEffect(() => { const sub = registerSnoozeHandler(); return () => sub.remove(); }, []);

  const inject = useCallback((js) => { web.current && web.current.injectJavaScript(js + ';true;'); }, []);

  // Daily-brief notification tap: opens straight into the brief popup rather than just the app.
  // Works whether Forge was backgrounded (registerDailyBriefHandler fires live) or fully killed
  // (wasLaunchedFromDailyBrief checks the launch that started this session) — either way, if the
  // WebView hasn't finished its first load yet, the request queues in pendingBriefRef and fires
  // once onLoadEnd flips pageReadyRef (see the WebView below).
  const openBrief = useCallback(() => {
    if (pageReadyRef.current) inject('window.__forgeNative&&window.__forgeNative.openDailyBrief&&window.__forgeNative.openDailyBrief()');
    else pendingBriefRef.current = true;
  }, [inject]);
  useEffect(() => {
    const sub = registerDailyBriefHandler(openBrief);
    wasLaunchedFromDailyBrief().then((was) => { if (was) openBrief(); });
    return () => sub.remove();
  }, [openBrief]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') inject('window.__forgeNative&&window.__forgeNative.onResume&&window.__forgeNative.onResume()');
    });
    const back = BackHandler.addEventListener('hardwareBackPress', () => {
      if (scanning) { closeScanner(null); return true; }
      if (photoCapture) { closePhotoCapture(null); return true; }
      inject('window.__forgeNative&&window.__forgeNative.back&&window.__forgeNative.back()');
      return true;
    });
    return () => { sub.remove(); back.remove(); };
  }, [inject, scanning, photoCapture]);

  const closeScanner = useCallback((value) => {
    setScanning(false);
    if (scanResolver.current) { scanResolver.current(value); scanResolver.current = null; }
  }, []);

  // Photo capture resolves with { ok, text } (from on-device OCR) rather than the raw photo — the
  // web layer only ever needs the recognized text to parse, same shape whether the label read
  // cleanly, came back empty, or capture was cancelled (ok:false, text:'').
  const closePhotoCapture = useCallback((uri) => {
    setPhotoCapture(null);
    const resolve = photoResolver.current;
    photoResolver.current = null;
    if (!resolve) return;
    if (!uri) { resolve({ ok: false, text: '' }); return; }
    recognizeTextFromPhoto(uri).then(resolve);
  }, []);

  const onMessage = useCallback(async (e) => {
    let msg; try { msg = JSON.parse(e.nativeEvent.data); } catch (_) { return; }
    const { id, type, payload } = msg || {};
    if (type === 'theme') { setChrome({ bg: payload.bg || DARK, dark: !!payload.dark }); return inject(`window.__forgeNative.resolve(${id},true,{})`); }
    if (type === 'scanBarcode') {
      setScanning(true);
      scanResolver.current = (code) => {
        if (code) inject(`window.__forgeNative.resolve(${id},true,${JSON.stringify({ code })})`);
        else inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify('cancelled')})`);
      };
      return;
    }
    if (type === 'scanPhoto') {
      setPhotoCapture({ hint: (payload && payload.hint) || '' });
      photoResolver.current = (result) => {
        if (result && result.ok) inject(`window.__forgeNative.resolve(${id},true,${JSON.stringify({ text: result.text || '' })})`);
        else inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify((result && result.message) || 'cancelled')})`);
      };
      return;
    }
    const fn = HANDLERS[type];
    if (!fn) return inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify('unknown request')})`);
    try {
      const data = await fn(payload || {});
      inject(`window.__forgeNative.resolve(${id},true,${JSON.stringify(data === undefined ? {} : data)})`);
    } catch (err) {
      inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify(String((err && err.message) || err))})`);
    }
  }, [inject]);

  // CSS env(safe-area-inset-top) is unreliable inside an Android WebView (often just resolves to
  // 0px, unlike iOS Safari), and current Expo/RN Android builds go edge-to-edge by default, so
  // without this the page's own background was drawing straight under the system status bar with
  // no reserved gap — looked exactly like a layer covering the clock/notification icons. Real
  // insets come from react-native-safe-area-context (useSafeAreaInsets above) and get pushed into
  // the page as --safe-t-native/--safe-b-native, which the CSS combines with env() via max().
  const safeAreaInsetsJS = useCallback((top, bottom) =>
    `(function(){try{document.documentElement.style.setProperty('--safe-t-native','${top}px');document.documentElement.style.setProperty('--safe-b-native','${bottom}px');}catch(e){}})();`,
  []);

  return (
    <View style={{ flex: 1, backgroundColor: chrome.bg }}>
      <StatusBar barStyle={chrome.dark ? 'light-content' : 'dark-content'} backgroundColor={chrome.bg} translucent={false} />
      <WebView
        ref={web}
        style={{ flex: 1, backgroundColor: DARK }}
        originWhitelist={['*']}
        source={{ html: forgeHtml, baseUrl: 'https://forge.local/' }}
        javaScriptEnabled
        domStorageEnabled
        allowFileAccess={false}
        setSupportMultipleWindows={false}
        overScrollMode="never"
        onMessage={onMessage}
        injectedJavaScriptBeforeContentLoaded={safeAreaInsetsJS(insets.top, insets.bottom)}
        onLoadEnd={() => {
          pageReadyRef.current = true;
          // Belt-and-suspenders re-apply once the page's own script has definitely run (and its
          // own :root defaults are in place) — injectedJavaScriptBeforeContentLoaded's exact timing
          // relative to the page's inline <script> isn't guaranteed across Android WebView versions.
          inject(safeAreaInsetsJS(insets.top, insets.bottom));
          if (pendingBriefRef.current) {
            pendingBriefRef.current = false;
            inject('window.__forgeNative&&window.__forgeNative.openDailyBrief&&window.__forgeNative.openDailyBrief()');
          }
        }}
        onShouldStartLoadWithRequest={(req) => {
          if (req.url.startsWith('https://forge.local') || req.url === 'about:blank') return true;
          if (/^https?:/.test(req.url)) { Linking.openURL(req.url); }
          return false;
        }}
      />
      {scanning && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
          <BarcodeScanner onScan={(code) => closeScanner(code)} onCancel={() => closeScanner(null)} />
        </View>
      )}
      {photoCapture && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
          <PhotoCapture hint={photoCapture.hint} onCapture={(uri) => closePhotoCapture(uri)} onCancel={() => closePhotoCapture(null)} />
        </View>
      )}
    </View>
  );
}

export default function App() {
  return (<SafeAreaProvider><Shell /></SafeAreaProvider>);
}
