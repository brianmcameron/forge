import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, AppState, BackHandler, Linking, Pressable, Share, StatusBar, StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import forgeHtml from './src/forgeHtml';
import { TRENDS_URL } from './src/config';
import { initFoodDb, searchFoods } from './src/foodDb';
import { healthStatus, healthConnect, healthToday } from './src/health';
import { scheduleReminders } from './src/reminders';
import { googleSignIn, googleSignOut } from './src/googleAuth';
import { driveBackupNow, driveRestore } from './src/drive';
import { googleAuthAvailable, googleStatus, googleSignIn, googleSignOut } from './src/googleAuth';
import { driveBackup, driveRestore } from './src/driveBackup';

const DARK = '#1b0a2a'; // matches the launch animation
const ONBOARD_KEY = 'forge_onboarded_v1';

async function fetchTrends() {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(TRENDS_URL + '?t=' + Date.now(), { signal: ctl.signal });
    if (!r.ok) throw new Error('http ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

const HANDLERS = {
  foodSearch: ({ q, limit }) => searchFoods(String(q || ''), Math.min(+limit || 24, 40)),
  trends: () => fetchTrends(),
  openUrl: async ({ url }) => { if (/^https?:\/\//.test(String(url))) await Linking.openURL(url); return {}; },
  shareBackup: async ({ text, name }) => { await Share.share({ message: String(text), title: String(name || 'forge-backup.json') }); return {}; },
  healthStatus: () => healthStatus(),
  healthConnect: () => healthConnect(),
  healthToday: () => healthToday(),
  scheduleReminders: ({ supplements }) => scheduleReminders(supplements || []),
  googleSignIn: () => googleSignIn(),
  googleSignOut: () => googleSignOut(),
  driveBackupNow: ({ json }) => driveBackupNow(json),
  driveRestore: () => driveRestore(),
  googleStatus: () => googleStatus(),
  googleSignIn: () => googleSignIn(),
  googleSignOut: () => googleSignOut(),
  driveBackup: ({ json }) => driveBackup(json),
  driveRestore: () => driveRestore(),
  exit: async () => { BackHandler.exitApp(); return {}; },
};

function Shell() {
  const web = useRef(null);
  const insets = useSafeAreaInsets();
  const [chrome, setChrome] = useState({ bg: DARK, dark: true });

  useEffect(() => { initFoodDb(); }, []);

  const inject = useCallback((js) => { web.current && web.current.injectJavaScript(js + ';true;'); }, []);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') inject('window.__forgeNative&&window.__forgeNative.onResume&&window.__forgeNative.onResume()');
    });
    const back = BackHandler.addEventListener('hardwareBackPress', () => {
      inject('window.__forgeNative&&window.__forgeNative.back&&window.__forgeNative.back()');
      return true;
    });
    return () => { sub.remove(); back.remove(); };
  }, [inject]);

  const onMessage = useCallback(async (e) => {
    let msg; try { msg = JSON.parse(e.nativeEvent.data); } catch (_) { return; }
    const { id, type, payload } = msg || {};
    if (type === 'theme') { setChrome({ bg: payload.bg || DARK, dark: !!payload.dark }); return inject(`window.__forgeNative.resolve(${id},true,{})`); }
    const fn = HANDLERS[type];
    if (!fn) return inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify('unknown request')})`);
    try {
      const data = await fn(payload || {});
      inject(`window.__forgeNative.resolve(${id},true,${JSON.stringify(data === undefined ? {} : data)})`);
    } catch (err) {
      inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify(String((err && err.message) || err))})`);
    }
  }, [inject]);

  return (
    <View style={{ flex: 1, backgroundColor: chrome.bg, paddingTop: insets.top, paddingBottom: insets.bottom }}>
      <StatusBar barStyle={chrome.dark ? 'light-content' : 'dark-content'} backgroundColor="transparent" translucent />
      <WebView
        ref={web}
        style={{ flex: 1, backgroundColor: DARK }}
        originWhitelist={['*']}
        source={{ html: forgeHtml, baseUrl: 'https://forge.local/' }}
        javaScriptEnabled
        domStorageEnabled
        allowFileAccess={false}
        setSupportMultipleWindows={false}
        overScrollMode="never"
        onMessage={onMessage}
        onShouldStartLoadWithRequest={(req) => {
          if (req.url.startsWith('https://forge.local') || req.url === 'about:blank') return true;
          if (/^https?:/.test(req.url)) { Linking.openURL(req.url); }
          return false;
        }}
      />
    </View>
  );
}

function Welcome({ onDone }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const available = googleAuthAvailable();

  const finish = async () => { await AsyncStorage.setItem(ONBOARD_KEY, '1'); onDone(); };

  const signIn = async () => {
    setBusy(true); setErr(null);
    const res = await googleSignIn();
    setBusy(false);
    if (res.ok) finish();
    else setErr(res.reason === 'not_configured' ? null : 'Sign-in didn’t go through — you can try again or continue without an account.');
  };

  return (
    <View style={styles.welcome}>
      <View style={styles.bolt}><Text style={styles.boltTxt}>⚡</Text></View>
      <Text style={styles.title}>Welcome to Forge</Text>
      <Text style={styles.sub}>Sign in with Google to back up your workouts, food log and supplements to your Drive. Everything stays local either way — sign-in only adds an optional backup.</Text>
      {available ? (
        <Pressable style={[styles.btn, styles.btnPrimary]} onPress={signIn} disabled={busy}>
          {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnPrimaryTxt}>Sign in with Google</Text>}
        </Pressable>
      ) : (
        <Text style={styles.note}>Google sign-in isn’t set up for this build yet — continue without an account for now.</Text>
      )}
      {err ? <Text style={styles.err}>{err}</Text> : null}
      <Pressable style={styles.btn} onPress={finish} disabled={busy}>
        <Text style={styles.btnTxt}>Continue without an account</Text>
      </Pressable>
      <Text style={styles.foot}>You can sign in or out anytime from Forge's Menu → Account & backup.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  welcome: { flex: 1, backgroundColor: DARK, alignItems: 'center', justifyContent: 'center', padding: 28 },
  bolt: { width: 84, height: 84, borderRadius: 42, backgroundColor: '#EB1B76', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  boltTxt: { fontSize: 38 },
  title: { color: '#fff', fontSize: 26, fontWeight: '800', marginBottom: 10, textAlign: 'center' },
  sub: { color: '#D8C7DE', fontSize: 14.5, textAlign: 'center', lineHeight: 21, marginBottom: 28 },
  btn: { width: '100%', paddingVertical: 15, borderRadius: 14, alignItems: 'center', marginTop: 12 },
  btnPrimary: { backgroundColor: '#EB1B76' },
  btnPrimaryTxt: { color: '#fff', fontWeight: '800', fontSize: 15.5 },
  btnTxt: { color: '#D8C7DE', fontWeight: '700', fontSize: 14.5 },
  note: { color: '#B4A6B7', fontSize: 12.5, textAlign: 'center', marginTop: 4 },
  err: { color: '#FF8FB4', fontSize: 12.5, textAlign: 'center', marginTop: 10 },
  foot: { color: '#7C6E80', fontSize: 11.5, textAlign: 'center', marginTop: 22 },
});

export default function App() {
  const [ready, setReady] = useState(false);
  const [onboarded, setOnboarded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(ONBOARD_KEY).then((v) => { setOnboarded(!!v); setReady(true); });
  }, []);

  if (!ready) return <View style={{ flex: 1, backgroundColor: DARK }} />;

  return (
    <SafeAreaProvider>
      {onboarded ? <Shell /> : <Welcome onDone={() => setOnboarded(true)} />}
    </SafeAreaProvider>
  );
}
