import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, BackHandler, Linking, Share, StatusBar, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import forgeHtml from './src/forgeHtml';
import { TRENDS_URL } from './src/config';
import { initFoodDb, searchFoods } from './src/foodDb';
import { healthStatus, healthConnect, healthToday, healthExerciseSessions, healthHistory } from './src/health';
import { scheduleReminders, registerSnoozeHandler, sendRecapNotification, scheduleMaintenanceAlerts } from './src/reminders';
import { googleSignIn, googleSignOut } from './src/googleAuth';
import { driveBackupNow, driveRestore } from './src/drive';
import { updateWorkoutNotification, clearWorkoutNotification } from './src/workoutNotify';
import BarcodeScanner from './src/BarcodeScanner';
import { requestWidgetUpdate } from 'react-native-android-widget';
import { saveWidgetSnapshot } from './src/widgetData';
import { ForgeWidgetSmall, ForgeWidgetMedium, ForgeWidgetLarge } from './src/ForgeWidget';

// One entry per size defined in app.json — every placed instance of every size refreshes
// together whenever the web layer pushes new data.
const WIDGET_COMPONENTS = {
  'Forge — Small': ForgeWidgetSmall,
  'Forge — Medium': ForgeWidgetMedium,
  'Forge — Large': ForgeWidgetLarge,
};

const DARK = '#1b0a2a'; // matches the launch animation

async function fetchTrends() {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(TRENDS_URL + '?t=' + Date.now(), { signal: ctl.signal });
    if (!r.ok) throw new Error('http ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

const HANDLERS = {
  foodSearch: ({ q, limit }) => searchFoods(String(q || ''), Math.min(+limit || 24, 40)),
  trends: () => fetchTrends(),
  openUrl: async ({ url }) => { if (/^https?:\/\//.test(String(url))) await Linking.openURL(url); return {}; },
  shareBackup: async ({ text, name }) => { await Share.share({ message: String(text), title: String(name || 'forge-backup.json') }); return {}; },
  healthStatus: () => healthStatus(),
  healthConnect: () => healthConnect(),
  healthToday: () => healthToday(),
  healthSessions: ({ days }) => healthExerciseSessions(days || 7),
  healthHistory: ({ days }) => healthHistory(days || 7),
  scheduleReminders: ({ supplements }) => scheduleReminders(supplements || []),
  scheduleMaintenanceAlerts: ({ items }) => scheduleMaintenanceAlerts({ items: items || [] }),
  sendRecapNotification: ({ title, body }) => sendRecapNotification({ title, body }),
  googleSignIn: () => googleSignIn(),
  googleSignOut: () => googleSignOut(),
  driveBackupNow: ({ json }) => driveBackupNow(json),
  driveRestore: () => driveRestore(),
  updateWidgetData: async (snapshot) => {
    await saveWidgetSnapshot(snapshot);
    // Update every size — each is its own placed instance (or none at all), so a failure on
    // one (nothing of that size on the home screen) shouldn't stop the others from refreshing.
    await Promise.allSettled(Object.entries(WIDGET_COMPONENTS).map(([widgetName, Widget]) =>
      requestWidgetUpdate({ widgetName, renderWidget: () => <Widget snapshot={snapshot} /> })
    ));
    return {};
  },
  workoutNotifyUpdate: ({ title, body }) => updateWorkoutNotification({ title, body }),
  workoutNotifyClear: () => clearWorkoutNotification(),
  exit: async () => { BackHandler.exitApp(); return {}; },
};

function Shell() {
  const web = useRef(null);
  const [chrome, setChrome] = useState({ bg: DARK, dark: true });
  const [scanning, setScanning] = useState(false);
  const scanResolver = useRef(null);

  useEffect(() => { initFoodDb(); }, []);
  useEffect(() => { const sub = registerSnoozeHandler(); return () => sub.remove(); }, []);

  const inject = useCallback((js) => { web.current && web.current.injectJavaScript(js + ';true;'); }, []);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') inject('window.__forgeNative&&window.__forgeNative.onResume&&window.__forgeNative.onResume()');
    });
    const back = BackHandler.addEventListener('hardwareBackPress', () => {
      if (scanning) { closeScanner(null); return true; }
      inject('window.__forgeNative&&window.__forgeNative.back&&window.__forgeNative.back()');
      return true;
    });
    return () => { sub.remove(); back.remove(); };
  }, [inject, scanning]);

  const closeScanner = useCallback((value) => {
    setScanning(false);
    if (scanResolver.current) { scanResolver.current(value); scanResolver.current = null; }
  }, []);

  const onMessage = useCallback(async (e) => {
    let msg; try { msg = JSON.parse(e.nativeEvent.data); } catch (_) { return; }
    const { id, type, payload } = msg || {};
    if (type === 'theme') { setChrome({ bg: payload.bg || DARK, dark: !!payload.dark }); return inject(`window.__forgeNative.resolve(${id},true,{})`); }
    if (type === 'scanBarcode') {
      setScanning(true);
      scanResolver.current = (code) => {
        if (code) inject(`window.__forgeNative.resolve(${id},true,${JSON.stringify({ code })})`);
        else inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify('cancelled')})`);
      };
      return;
    }
    const fn = HANDLERS[type];
    if (!fn) return inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify('unknown request')})`);
    try {
      const data = await fn(payload || {});
      inject(`window.__forgeNative.resolve(${id},true,${JSON.stringify(data === undefined ? {} : data)})`);
    } catch (err) {
      inject(`window.__forgeNative.resolve(${id},false,${JSON.stringify(String((err && err.message) || err))})`);
    }
  }, [inject]);

  return (
    <View style={{ flex: 1, backgroundColor: chrome.bg }}>
      <StatusBar barStyle={chrome.dark ? 'light-content' : 'dark-content'} backgroundColor={chrome.bg} translucent={false} />
      <WebView
        ref={web}
        style={{ flex: 1, backgroundColor: DARK }}
        originWhitelist={['*']}
        source={{ html: forgeHtml, baseUrl: 'https://forge.local/' }}
        javaScriptEnabled
        domStorageEnabled
        allowFileAccess={false}
        setSupportMultipleWindows={false}
        overScrollMode="never"
        onMessage={onMessage}
        onShouldStartLoadWithRequest={(req) => {
          if (req.url.startsWith('https://forge.local') || req.url === 'about:blank') return true;
          if (/^https?:/.test(req.url)) { Linking.openURL(req.url); }
          return false;
        }}
      />
      {scanning && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
          <BarcodeScanner onScan={(code) => closeScanner(code)} onCancel={() => closeScanner(null)} />
        </View>
      )}
    </View>
  );
}

export default function App() {
  return (<SafeAreaProvider><Shell /></SafeAreaProvider>);
}
